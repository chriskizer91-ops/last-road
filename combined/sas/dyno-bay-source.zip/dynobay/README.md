# Redline County: Dyno Bay (Studio 2) and Salt & Sand

Two pages from the same build:

- `dyno-bay.html`: the garage and dyno bay alone (below).
- `salt-and-sand.html` (`--dunes`): the same garage and dyno bay as the menu, and the car **driven** as its full
  Studio 2 on a world of half salt flats, half white sand dunes, with a two-lane road through the middle (see
  **Salt & Sand** further down).


`dyno-bay.html` is Redline County: Wide Open 2: Road Not Found + Traffic cut down to its garage and dyno bay, with
the car on the turntable and the dyno drawn as its **Studio 2** (Salt Mini Plus's models). One self-contained page
(about 3.3 MB). Open it in Edge on the laptop.

## What's in it

- **The game's own garage and dyno bay**, unchanged underneath: the Digital Engine sound, the dyno lab (tach and
  shift lights, the dyno sheet, torque and power, firing order, sound, spectrogram, the Tune sheet), Free rev and
  Drive, the dyno pull, Plus, the presets, the parts, the ratings, Build it for me.
- **The car is Studio 2**: the SUV (Stock, Sleeper, Rock & Mud, Race), the Coupe (Stock, GT), the Hatch (Stock,
  Group B) and the Wedge (Stock, Night Runner). It moves exactly as the game's car does on the dyno: it squats as it
  pulls, nods at every shift, surges against the straps, rocks to the torque and shakes at a lumpy idle; the driven
  wheels turn the drums (the calipers stay put). Studio 2's engine is a piece of its own: it rocks on its mounts
  with the torque and shudders with the revs. Flames come out of Studio 2's own exhaust tips. The windows and clear
  lamp lenses are see-through, so the cabin and the lamps' insides show.
- **The camera reaches like the Studio 2 viewer's**: drag to go round it, all the way over and underneath; scroll
  or pinch to come in close (to about a metre); right-drag, Shift-drag or two fingers to slide along the car;
  double-click to come back to its middle. Under the floor, the floor, the turntable and the dyno's deck get out of
  the way and two lamps light it from below, as on a lift. There's an **Under** view with the others.
- It opens in the bay, on the dyno, hood up. **◀ Garage** (or Esc) is the garage; Esc there comes back to the bay.
- **Only the full Studio 2 is ever on screen** (the viewer's Studio 2, the same triangle count): no game's own car
  while it's made (the dyno stands empty under a "Building the Studio 2 …" line for those few seconds) and no shed of
  the game's own parked cars. The game's own car shows only if a Studio 2 couldn't be built at all.
- **Full resolution:** laptops start on the High graphics tier, and the bay is drawn at the tier's full size every
  frame (the render size never drops to keep the frame rate up). The views sit a little closer than the game's, so
  the car fills more of the picture.
- Its own saves (`dyb:`), so it never touches Road Not Found's.

## What Studio 2 doesn't show yet

- Studio 2 is each build as it's modelled, so the garage's Body kit, Tires, Suspension and Wheels slots are left out
  (pick the build under Start from). Paint and everything under the skin can be changed.
- The engine bay is the build's own: an engine swap or a power adder is heard and felt on the dyno, not seen.

## How it works

- `build.py` takes the game's page and Salt Mini Plus's `models/src`, and changes the game only by replacing pieces
  of its text that must be there exactly once (it stops if the game has changed under it):
  `python3 -I build.py <game.html> <salt-mini-plus/models/src> dyno-bay.html`
- The Studio kit (the game's builders, the Studio kit, each car's detail, in the viewer's order) goes into the page as
  text. A worker builds the car from it (`src/s2make.js`: `KIT.setAlt('2')`, `KIT.keepEngine(true)`), so the bay
  keeps running while it's made (2 to 7 seconds); the dyno stands empty until then. The last two built are kept on
  the graphics card.
- `src/s2.js` draws it in the game's renderer in place of the game's car on the turntable (body, glass, hood and
  pad on the hinge, engine on its mounts, wheels and brakes), 13 or 14 draws.
- `src/s2shader.glsl` adds the Studio kit's own materials (ids 70 to 108) to the game's car shader.
- `src/s2cam.js` is the bay's camera hands.
- `tools/check.js` boots the page in a test browser, drives the car through the gears on the dyno, and shoots the
  views and every build (`node tools/check.js dyno-bay.html /tmp/out all`).

## Numbers (from the test browser)

| Build | Triangles | Draws | Built in |
|---|---|---|---|
| SUV Stock | 808,095 | 13 | 5.8 s |
| SUV Sleeper | 892,380 | 13 | 3.6 s |
| SUV Rock & Mud | 790,531 | 13 | 3.3 s |
| SUV Race | 764,065 | 13 | 2.8 s |
| Coupe Stock | 707,820 | 13 | 2.6 s |
| Coupe GT | 653,407 | 13 | 2.7 s |
| Hatch Stock | 597,831 | 13 | 1.6 s |
| Hatch Group B | 653,575 | 14 | 1.8 s |
| Wedge Stock | 590,493 | 14 | 1.9 s |
| Wedge Night Runner | 637,948 | 14 | 2.3 s |

The test browser has no graphics card, so its frame rate means nothing; F in the bay shows the laptop's.

## Salt & Sand (`python3 -I build.py <game.html> <models/src> salt-and-sand.html --dunes`)

- **The world** (`src/sas_world.js`, asked first by the world's generator): a two-lane blacktop east and west the whole
  way across (the series' Highway 40, yellow line and edge lines); north of it the salt flats, flat and hard; south of
  it white gypsum dunes, rising out of the flat sand beside the road to ridges about 12 m tall within 75 m of it. The
  ridges run north and south, wavering, a long gentle slope up the west side and a steep slip face (about 33 degrees
  on the big ones) down the east side, each one a different size, the crests rising and falling. The sand has its
  own look in the ground shader (cream white, the wind's ripples) and its own surface for the physics (`sand`: each
  tyre's own grip on it, rolling drag 0.035), and kicks up white dust. Nothing else: no town, trees, traffic,
  police, challenges or jobs. The desert's air is clearer than the county's and the exposure set for white sand.
- **The car you drive is its full Studio 2**, the same car as in the bay: the body and glass, the hood, the engine
  shuddering with the revs, the wheels rolling and steering at their hubs where the physics has them, the calipers
  steering only, flames from its own tips. The sun's far shadow cascades take the game's coarse copy; the near one,
  where its shadow is seen, is Studio 2.
- **The menu is the bay**: it opens there; **Drive ▶** goes out onto the road; Esc on the road comes back to the bay;
  ◀ Garage is the garage; the Drive tab has the car, the build, the driving level, the time of day (it starts at High
  noon), the camera and the nitrous.
- Everything else is Road Not Found's own: the physics, the engine sound, the HUD and map, the cameras, the feats
  (air, speed runs, drifts).
- **The cameras: Chase, Far, Hood and Cinematic** (C, or CAM on a phone, steps through them). Cinematic is Salt
  Flats' camera crew: a camera standing still well ahead of the car (about eight seconds of driving at its speed, 60 m
  to a kilometre), turning to follow it as it comes, passes and goes, and zooming to keep it framed, the zoom easing
  in a second or two behind it; each shot about fourteen seconds, then the next camera further on, most often on the
  other side, at another height. On the dunes it's raised until it sees over the ridges. Heard from where it
  stands, the pitch up as the car comes and down as it goes. Tested: at 54 to 95 mph on the road, a camera 172 m
  ahead on a 2.4-degree lens, the car past it, then the next one 297 m on.
- **Low drone** (on the Drive tab next to Cinematic; last in the C / CAM round): a slower Cinematic from about
  50 ft (13 to 18 m) up. It sets up ahead of the car and off to one side and flies the same way at half the car's
  speed, so the car takes its time catching it, comes by below it and draws away, the drone drifting in toward the
  car's line: shots of about 22 seconds (Cinematic's are 14). It turns and zooms after the car lazily, the car about
  a fifth of the picture with the country round it. Over the dunes it climbs until it sees the car. Heard from where
  it flies. Tested at 52 to 90 mph on the road: set up 165 m ahead, closest 26 m, shots of 22 s; over the dunes it
  went from 15.6 to 20.4 m above the sand.
- **The drones** come after Cinematic: **Drone lead, Drone tail, Drone left, Drone right and Drone orbit**. Each
  flies about 100 ft (30.5 m) above the car and 22 m out from it, looking down at it. The four hold their station
  off the way the car is going (ahead, behind, its left, its right), swinging round slowly when it turns so a spin
  doesn't whip the picture. Drone orbit circles the car once every 48 seconds whatever the car does, its height
  and distance drifting a little, for the aerial shots. On the Drive tab, **Drone** tapped again steps through the
  four; **Orbit** is its own button. Tested: at 49 to 64 mph, 30.6 m above the car and 22 m out on every one; in a
  handbrake spin the car turned 112 degrees in 3 seconds while Drone orbit went on round it 23 degrees (its own
  steady pace), and Drone tail swung 34 degrees after a car that turned 117.
- **Cameras you choose** (Settings, the **Cameras** drop-down): each camera **On** or **Off**, and its **Director
  time** (4 to 60 s, the − and + beside it). The camera button (C, or CAM on a phone) and the Drive tab's camera row
  only go through the ones that are on; one always stays on. Saved. At first all are on but Far and the four fixed
  high drones.
  - **Director** (On/Off, also the last button on the Drive tab's camera row): switches by itself between the cameras
    that are on, holding each for its time, never the same one twice running. Tested with Chase 4 s, Drone follow
    4 s and Tracking car 6 s: it switched at 4.0, 8.2, 14.2, 18.3, 22.5 and 28.5 s.
  - **Jump cam** (On/Off): when the car leaves the ground properly (0.2 s in the air, half a metre up, over 18 mph) it
    cuts to a camera standing off to the side of where the jump goes, low, looking up at it, and back to your camera
    once the car has been down for 0.8 s. Heard from where it stands. Tested off a dune at 54 mph: in at 5.8 s, back
    at 7.5 s, the camera 11.5 m off the side.
- **Cockpit**: the driver's seat in Studio 2's own cabin. The eye is placed from the seat each car's model has (the
  seat furthest forward on the driver's side, 0.7 m up its back, kept 0.1 m under the roof), the cabin fixed round
  you, the head steadied a touch over bumps; the car's windows all but clear from inside. Heard from the cabin.
  Eyes: SUV 1.56 m up (0.16 m under the roof), Coupe 1.04 m, Hatch 1.21 m, Wedge 0.92 m, Race SUV 1.21 m.
- **Wheel cam**: fixed off the car's side at wheel height, far enough to get the whole side in (the SUV: 5.3 m out on
  a laptop's screen), going and turning with the car. Tapped again on the Drive tab: the other side.
- **Tracking car**: a camera car running alongside, low (about 1 m up), 8.5 m out, a longer lens, its arm sweeping
  from the front quarter round to the rear quarter and back every 26 s (tested: 36 to 144 degrees from the nose).
- **Roadside**: a camera on the ground (35 cm up) 4 to 6 m off the car's line ahead of it, a wide lens panning as the
  car blasts past, then the next one ahead. Heard from where it stands. Tested: the car past 4.8 m away at 57 mph.
- **Drone follow**: 50 ft up, close behind (12 m, more with speed), keeping right up with the car, drifting a little
  side to side and bobbing. Tested at 49 mph: 15.0 to 15.4 m above the car, 13.6 to 14.4 m behind, drifting from
  1.3 m one side to 1.5 m the other.
- **On a phone** the bar's one chip says **Bay** while you drive (tap it for the bay) and **Drive** in the menu. A
  phone keeps one Studio 2 car on its graphics card at a time (a laptop two).
- Its own saves (`sas:`).
- `tools/drive.js` drives it in a test browser (the road, the dunes, a jump, the salt) and shoots each;
  `tools/cine.js` the Cinematic camera, `tools/drone.js` the drones, `tools/lowdrone.js` the low drone,
  `tools/cams.js` the cameras chosen, the Director, Jump cam and the cockpits, `tools/camsui.js` their menus on a phone.

Measured in the test browser: the SUV Stock to 58 mph on the road in 7 s; 41 mph across the sand in 5 s; off a dune
crest at about 50 mph, 1.0 s in the air; 60 mph on the salt. A frame: 808,095 triangles of car and about 40,000 of
ground and road, 150 to 300 draws.
