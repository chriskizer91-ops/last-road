/* =====================================================================================
   REDLINE COUNTY: DYNO BAY. The game's own garage and dyno bay (63_garage, 63_showroom, 63_dyno_lab), with the car
   on the turntable and the dyno drawn as its Studio 2 (Salt Mini Plus's models): the same car, the same physics,
   engine, sound, tuner and dyno, only every part of it modelled for a close look. The four cars that have a
   Studio 2 for every one of their builds are in the garage: the SUV (Stock, Sleeper, Rock & Mud, Race), the Coupe
   (Stock, GT), the Hatch (Stock, Group B) and the Wedge (Stock, Night Runner).
   The Studio 2 car is built in a worker from the kit's own source (S2KIT_SRC, with s2Make) so the bay keeps
   running while it's made (a few seconds), then handed to this renderer as meshes of its own. The game's own car
   stands in on the turntable until it's ready. The last two built are kept, so switching back is at once.
   The car moves exactly as the game's does on the dyno (63_showroom showBody): it squats as it pulls, nods at
   every shift, surges against the straps, rocks to the torque and shakes at a lumpy idle; the driven wheels turn
   the drums. On top of that, Studio 2's engine is a piece of its own: it rocks on its mounts with the torque (as the
   game's own engine does in its bay) and shudders with the revs (as Salt Flats' does).
   ===================================================================================== */
const S2_KEYS=['stock','sleeper','crawler','race','coupe','coupeGT','hatch','hatchB','wedge','wedgeNR'];
/* the garage's slots that change how the car looks: Studio 2 is each build as it's modelled, so these are its own
   (the build is picked under Start from); paint stays yours, it's a colour the shader lays on */
const DYB={cars:['suv','coupe','hatch','wedge'],hide:['kit','tires','ride','wheels'],S2:new Map(),order:[],want:null,busy:null,w:null,err:{},shown:'',shownT:0,tick:0,
  /* under the floor: the exposure's aim (the dark studio round it would otherwise brighten the picture too far), the two lamps below */
  uk:.6,ul:.2,noOcc:false,under:false};
const s2Key=i=>{const b=BUILDS[i];if(!b||b.machine)return null;const k=b.kit||b.id;return S2_KEYS.includes(k)?k:null;};
/* the Studio 2 car for a build, once it's made (else null, and it's asked for) */
function s2For(i){const k=s2Key(i);if(!k)return null;const S=DYB.S2.get(k);
  if(S){if(DYB.order[DYB.order.length-1]!==k){DYB.order=DYB.order.filter(q=>q!==k);DYB.order.push(k);}if(DYB.shown!==k){DYB.shown=k;DYB.shownT=performance.now();s2Badge();}return S;}
  if(!DYB.err[k]&&(!DYB.busy||DYB.busy.k!==k)&&DYB.want!==k){DYB.want=k;s2Pump();}
  return null;}
function s2Pump(){
  if(DYB.busy||!DYB.want)return;const k=DYB.want;DYB.want=null;if(DYB.S2.has(k)||DYB.err[k])return;
  DYB.busy={k,t0:performance.now()};s2Badge();
  const w=s2Worker();
  if(w)w.postMessage({key:k});
  /* (no worker on this browser: made here, the page held for those few seconds) */
  else setTimeout(()=>{let m;try{if(!DYB.inline)DYB.inline=new Function(S2KIT_SRC+'\n;\n'+S2MAKE_SRC+'\nreturn {K:window.KIT,make:s2Make};')();
      m=DYB.inline.make(DYB.inline.K,k).msg;}catch(e){m={ok:false,key:k,err:String(e&&e.stack||e)};}s2Done(m);},60);
}
function s2Worker(){
  if(DYB.w!==null)return DYB.w;
  try{const src='self.window=self;\n'+S2KIT_SRC+'\n;\n'+S2MAKE_SRC+
      '\nonmessage=e=>{const k=e.data.key;try{const r=s2Make(window.KIT,k);postMessage(r.msg,r.tr);}catch(err){postMessage({ok:false,key:k,err:String(err&&err.stack||err)});}};';
    const w=new Worker(URL.createObjectURL(new Blob([src],{type:'text/javascript'})));
    w.onmessage=e=>s2Done(e.data);
    /* (a worker that can't start: the rest are made on the page) */
    w.onerror=e=>{console.warn('Studio 2 worker:',e.message);try{e.preventDefault();}catch(_){}try{w.terminate();}catch(_){}DYB.w=false;
      if(DYB.busy){DYB.want=DYB.busy.k;DYB.busy=null;s2Pump();}};
    DYB.w=w;}catch(e){console.warn('Studio 2 worker:',e);DYB.w=false;}
  return DYB.w;}
/* a car made: up to the graphics card, its pieces as the game's own meshes */
function s2Done(m){
  const k=m.key||(m.info&&m.info.key)||(DYB.busy&&DYB.busy.k);DYB.busy=null;
  if(!m.ok){DYB.err[k]=m.err||'?';console.warn('Studio 2 '+k+' could not be built:',m.err);s2Badge();s2Pump();return;}
  const I=m.info,P=m.pieces,S={key:I.key,info:I,tris:0,draws:0};
  for(const [nm,d] of Object.entries(P)){S[nm]=makeMesh(d);}
  S.wheelR=S.wheelR||S.wheel;S.brakeR=S.brakeR||S.brake;
  for(const [nm,n] of Object.entries(I.tris)){const x=/^(wheel|brake)$/.test(nm)?(P[nm+'R']?2:4):/^(wheel|brake)R$/.test(nm)?2:1;S.tris+=n*x;S.draws+=x;}
  Object.assign(S,{pivot:I.pivot,trans:I.trans,tips:I.tips,hinge:I.hinge,hoodOpen:I.hoodOpen,fx:I.fx,wb:I.wb,pitch:I.pitch,R:I.R,Rr:I.Rr,tw:I.tw,twR:I.twR,ms:I.ms});
  DYB.S2.set(k,S);DYB.order=DYB.order.filter(q=>q!==k);DYB.order.push(k);
  /* the last two kept (one on a phone, for its graphics memory), the ones before let go */
  while(DYB.order.length>(touchy?1:2)){const o=DYB.order.shift(),Q=DYB.S2.get(o);DYB.S2.delete(o);if(Q){const seen=new Set();
    for(const nm of ['body','bodyG','hood','hoodG','liner','engine','wheel','wheelR','brake','brakeR'])if(Q[nm]&&!seen.has(Q[nm])){seen.add(Q[nm]);freeMesh(Q[nm]);}}}
  s2Badge();s2Pump();
}
/* the line at the top while a car is made, and for a moment once it's on (what it is: its triangles) */
function s2Badge(){
  let el=$('s2b');if(!el){el=document.createElement('div');el.id='s2b';document.body.appendChild(el);}
  const i=APP.bi,k=s2Key(i),nm=k?carName({car:APP.car})+' '+BUILDS.find(b=>b.id===k).name:'';
  let t='';
  if(k&&DYB.busy&&DYB.busy.k===k)t=`Building the Studio 2 ${nm}… ${Math.max(0,Math.round((performance.now()-DYB.busy.t0)/1000))} s`;
  else if(k&&!DYB.S2.has(k)&&DYB.err[k])t=`The Studio 2 ${nm} couldn't be built here: this is the game's own car`;
  else if(k&&DYB.S2.has(k)&&DYB.shown===k&&performance.now()-DYB.shownT<4000){const S=DYB.S2.get(k);t=`Studio 2 ${nm} · ${NF.format(Math.round(S.tris))} triangles`;}
  el.textContent=t;el.hidden=!t;
  clearTimeout(DYB.tick);if(t)DYB.tick=setTimeout(s2Badge,500);
}
/* the body on its springs (63_showroom showBodyM, with Studio 2's own hubs for the pitch over big rear tyres) */
function s2BodyM(S,Mc){
  const pv=.62;let Mb=M4.mul(Mc,M4.mul(M4T(SHOW.surge,pv+SHOW.shake[1],SHOW.shake[0]),M4.mul(M4RX(SHOW.roll),M4.mul(M4RZ(SHOW.pitch),M4T(0,-pv,0)))));
  if(S.pitch)Mb=M4.mul(Mb,M4.mul(M4T(S.fx,S.R,0),M4.mul(M4RZ(S.pitch),M4T(-S.fx,-S.R,0))));
  return Mb;}
/* the engine on its mounts: rocked over by the torque as the game's own bay engine is (three times the body's roll),
   and a shudder with the revs, quick and big at idle, smoothing out as it revs (Salt Flats': about 2 mm) */
function s2EngM(S,Mb){
  const sim=SHOW.sim,e=showE(),run=!!(SHOW.eng&&sim&&sim.running),rpm=run?Math.max(0,sim.rpm||0):0,p=S.pivot;
  const red=(e&&e.redline)||6500,on=rpm>50,f=Math.min(rpm/60*2,22),idleK=clamp(1.3-rpm/red*1.4,.3,1.3),amp=on?.0019*idleK:0,w=TAU*f*APP.t;
  const y=amp*(Math.sin(w)+.55*Math.sin(1.37*w+1.3)),a=-SHOW.roll*3+amp*3.2*Math.sin(.5*w+.4);
  return M4.mul(Mb,M4.mul(M4T(p[0],p[1]+y,p[2]),M4.mul(S.trans?M4RZ(a):M4RX(a),M4T(-p[0],-p[1],-p[2]))));}
/* the live car as Studio 2 (in place of 63_showroom drawShowCar's own car; du: the shadow map's uniforms) */
function drawS2Car(i,Mc,hoodA,dirt,du,S){
  const u=du||CUR.u;if(!du){showCarUniforms(i,dirt);gl.uniform1f(u.uMudLocal,1);gl.uniform1f(u.uMudOff,0);}
  const Mb=s2BodyM(S,Mc);
  gl.uniformMatrix4fv(u.uM,false,Mb);drawMesh(S.body);if(!du&&S.bodyG)drawMesh(S.bodyG);
  if(S.engine){gl.uniformMatrix4fv(u.uM,false,S.pivot?s2EngM(S,Mb):Mb);drawMesh(S.engine);}
  const ha=sstep(0,1,hoodA);let Mh=Mb;
  if(ha>0){const [hx,hy]=S.hinge;Mh=M4.mul(Mb,M4.mul(M4T(hx,hy,0),M4.mul(M4RZ(ha*S.hoodOpen),M4T(-hx,-hy,0))));}
  gl.uniformMatrix4fv(u.uM,false,Mh);if(S.hood)drawMesh(S.hood);if(!du&&S.hoodG)drawMesh(S.hoodG);if(S.liner)drawMesh(S.liner);
  /* a bang in the pipes throws a flame out of each of Studio 2's own tips */
  const v=GAME.voice;
  if(!du&&v.flame>.04&&S.tips)for(const tp of S.tips){
    const up=Math.abs(tp.d[1])>.9?[1,0,0]:[0,1,0],rr=V3.norm(V3.cross(tp.d,up)),uu=V3.cross(rr,tp.d),k=Math.min(1,v.flame),fl=(.12+.42*k*v.flameL)*(.85+.3*Math.random()),fr=tp.r*(.8+.5*k);
    gl.uniformMatrix4fv(u.uM,false,M4.mul(Mb,M4.mul(M4.basis(tp.p,tp.d,uu,rr),M4S(fl,fr,fr))));drawMesh(flameMesh());}
  /* on the dyno only the driven wheels turn; what only steers (the calipers) stays put */
  const sp=specOf(i),eR=sp.R,drv=sp.drv||'RWD';
  for(const front of [1,0])for(const s of [1,-1]){const wa=drv==='AWD'||(drv==='FWD')===!!front?-SHOW.wheelA:0;
    const x=front?S.fx:S.fx-S.wb*Math.cos(S.pitch),Rw=front?S.R:S.Rr,tw=front?S.tw:S.twR;if(!du)gl.uniform1f(u.uMudOff,Rw);
    const Mw=M4.mul(Mc,M4.mul(M4T(x,Rw,s*tw),M4S(1,1,s)));
    gl.uniformMatrix4fv(u.uM,false,M4.mul(Mw,M4RZ(wa*eR/Rw)));drawMesh(front?S.wheel:S.wheelR);
    const br=front?S.brake:S.brakeR;if(br){gl.uniformMatrix4fv(u.uM,false,Mw);drawMesh(br);}}
  if(!du){gl.uniform1f(u.uMudOff,0);gl.uniform1f(u.uMudLocal,0);}
  return S.tris;
}
/* the page: the garage and the bay only, opened on the bay */
function dybCars(){const keep=CARS.filter(c=>DYB.cars.includes(c[0]));CARS.splice(0,CARS.length,...keep);if(!DYB.cars.includes(APP.car))APP.car='suv';}
function dybStart(){showTab('garage');showFull(true);s2For(APP.bi);}
