/* drag to turn round the car, all the way over it and underneath (as the Studio 2 viewer does); pinch or scroll to
   come closer, right in to a wheel; drag with the right button (or Shift, or two fingers) to slide the centre of
   the view along the car; double-click to put it back on the car's middle (the bay's own hands, Dyno Bay's reach) */
function showPointer(){
  const P=new Map();let pinch0=0,d0=0,mid0=null,btn=0;
  const cam=()=>{if(!SHOW.camT||SHOW.view){SHOW.camT=Object.assign({},SHOW.cam||showViewOf(SHOW.view));SHOW.view=null;syncShow();}return SHOW.camT;};
  const pan=(c,dx,dy)=>{const th=c.th*PI/180,ph=c.ph*PI/180,f=[-Math.cos(ph)*Math.cos(th),-Math.sin(ph),Math.cos(ph)*Math.sin(th)],
      r=V3.norm(V3.cross(f,[0,1,0])),u=V3.cross(r,f),k=c.d*.0016;
    c.ox=clamp((c.ox||0)-(r[0]*dx-u[0]*dy)*k,-3.4,3.4);c.oy=clamp((c.oy||0)-(r[1]*dx-u[1]*dy)*k,-.9,2.6);c.oz=clamp((c.oz||0)-(r[2]*dx-u[2]*dy)*k,-3.4,3.4);};
  cv.addEventListener('contextmenu',e=>{if(SHOW.full)e.preventDefault();});
  cv.addEventListener('pointerdown',e=>{if(!SHOW.full)return;P.set(e.pointerId,[e.clientX,e.clientY]);if(P.size===1)btn=e.button;try{cv.setPointerCapture(e.pointerId);}catch(_){}
    if(P.size===2){const [a,b]=[...P.values()];pinch0=Math.hypot(a[0]-b[0],a[1]-b[1]);d0=cam().d;mid0=[(a[0]+b[0])/2,(a[1]+b[1])/2];}});
  cv.addEventListener('pointermove',e=>{if(!SHOW.full||!P.has(e.pointerId))return;const q=P.get(e.pointerId),dx=e.clientX-q[0],dy=e.clientY-q[1];P.set(e.pointerId,[e.clientX,e.clientY]);
    const c=cam();
    if(P.size===1){if(btn===1||btn===2||e.shiftKey)pan(c,dx,dy);else{c.th-=dx*.35;c.ph=clamp(c.ph+dy*.25,-80,88);}}
    else if(P.size===2&&pinch0>0){const [a,b]=[...P.values()];c.d=clamp(d0*pinch0/Math.max(20,Math.hypot(a[0]-b[0],a[1]-b[1])),1.1,22);
      const m=[(a[0]+b[0])/2,(a[1]+b[1])/2];if(mid0)pan(c,m[0]-mid0[0],m[1]-mid0[1]);mid0=m;}});
  const up=e=>{P.delete(e.pointerId);if(P.size<2){pinch0=0;mid0=null;}};for(const ev of ['pointerup','pointercancel'])cv.addEventListener(ev,up);
  cv.addEventListener('wheel',e=>{if(!SHOW.full)return;e.preventDefault();const c=cam();c.d=clamp(c.d*Math.pow(1.0015,e.deltaY),1.1,22);},{passive:false});
  cv.addEventListener('dblclick',e=>{if(!SHOW.full)return;const c=cam();c.ox=c.oy=c.oz=0;});
}
