/* =====================================================================================
   THE STUDIO 2 CAR, MADE (in the worker, or on the page if a worker can't start). The kit (Salt Mini Plus's
   models/src: the game's builders, the Studio kit, each car's own detail, in the viewer's order) builds the car
   exactly as the Studio 2 viewer does it (KIT.setAlt('2'), the bodies' stations four times closer together), with
   the engine kept a piece of its own (KIT.keepEngine) so the dyno can shake it on its mounts. What comes back is in
   the game's own mesh form (positions, normals, colour + glow, material, per vertex), in pieces:
   - body: the shell and every Studio part fixed to it, the whole underside and the engine bay around the engine
   - bodyG, hoodG: what you see through (the windows, the clear lamp lenses), kept apart so it casts no shadow; each
     vertex's glow is minus how much of it is kept, which the game's shader already reads as see-through
   - hood (with what lifts with it) and liner (the pad under it), on the hinge
   - engine, on its mounts
   - wheel / wheelR (what turns) and brake / brakeR (what only steers), front and back
   and the numbers to place them: the hubs, the hinge, the engine's pivot, the exhaust tips for the flames.
   ===================================================================================== */
function s2Make(K,key){
  K.setHD(true);K.setAlt('2');K.keepEngine(true);let T;self.KIT_SEATS=[];
  try{T=K.studioBuild(key,.25);}finally{K.setAlt('');K.keepEngine(false);}
  const MT=K.MAT,SM=K.SM,has=x=>x&&x.p&&x.p.length;
  /* how much of each see-through surface is kept (the Studio viewer's opacities) */
  const SEE={[MT.GLASS]:.72,[MT.GLASSL]:.45,[SM.LENS]:.2,[SM.LENSH]:.22,[SM.LENSR]:.25,[SM.TINT]:.6};
  const out={},tr=[],tris={};
  const pack=(name,list,split)=>{list=list.filter(has);let no=0,ng=0;
    for(const s of list){const M=s.m,nt=M.length/3;for(let t=0;t<nt;t++){if(split&&SEE[M[t*3]]!==undefined)ng++;else no++;}}
    const mk=n=>n?{pos:new Float32Array(n*9),nrm:new Float32Array(n*9),col:new Float32Array(n*12),mat:new Float32Array(n*3),k:0}:null;
    const O=mk(no),G=mk(ng);
    for(const s of list){const P=s.p,N=s.n,C=s.c,M=s.m,nt=M.length/3;
      for(let t=0;t<nt;t++){const id=M[t*3],see=split?SEE[id]:undefined,D=see===undefined?O:G,k=D.k++,o9=k*9,o12=k*12,s9=t*9,s12=t*12;
        for(let j=0;j<9;j++){D.pos[o9+j]=P[s9+j];D.nrm[o9+j]=N[s9+j];}
        for(let j=0;j<12;j++)D.col[o12+j]=C[s12+j];
        if(see!==undefined)D.col[o12+3]=D.col[o12+7]=D.col[o12+11]=-see;
        D.mat[k*3]=D.mat[k*3+1]=D.mat[k*3+2]=id;}}
    for(const [sfx,D,n] of [['',O,no],['G',G,ng]])if(D){delete D.k;out[name+sfx]=D;tris[name+sfx]=n;tr.push(D.pos.buffer,D.nrm.buffer,D.col.buffer,D.mat.buffer);}};
  const body=[T.body];for(const [nm,src] of Object.entries(T.hd||{}))if(nm!=='hood')body.push(src);body.push(T.under);if(T.bay)body.push(T.bay.bay);
  pack('body',body,true);pack('hood',[T.hood,T.hd&&T.hd.hood],true);
  if(T.bay){pack('liner',[T.bay.liner]);pack('engine',[T.bay.engine]);}
  pack('wheel',[T.wheel]);if(T.wheelR&&T.wheelR!==T.wheel)pack('wheelR',[T.wheelR]);
  if(T.brake)pack('brake',[T.brake]);if(T.brakeR&&T.brakeR!==T.brake)pack('brakeR',[T.brakeR]);
  /* the engine's pivot: the bay's own, or (as Salt Flats does it) the middle of the engine, a third of the way up */
  let pivot=T.bay&&T.bay.pivot,trans=!!(T.bay&&T.bay.trans);
  if(!pivot&&out.engine){const P=out.engine.pos;let a=[1e9,1e9,1e9],b=[-1e9,-1e9,-1e9];
    for(let i=0;i<P.length;i+=3)for(let k=0;k<3;k++){if(P[i+k]<a[k])a[k]=P[i+k];if(P[i+k]>b[k])b[k]=P[i+k];}
    pivot=[(a[0]+b[0])/2,a[1]+(b[1]-a[1])*.35,0];}
  const D=T.D,lk=T.b.look,fx=D.X(D.uFa);
  const info={key,name:T.b.name,pivot:pivot?[+pivot[0],+pivot[1],+pivot[2]]:null,trans,
    tips:(D.tips||[]).map(t=>({p:[...t.p],d:[...t.d],r:t.r})),hinge:[...D.hood.hinge],hoodOpen:D.hoodOpen||1,
    fx,wb:D.uRa-D.uFa,pitch:D.pitch||0,R:lk.tyre.R,Rr:D.Rr||lk.tyre.R,tw:lk.track/2,twR:(lk.trackR||lk.track)/2,tris,ms:Math.round(T.ms)};
  /* the driver's eye, for the Cockpit camera: the seat the kit made furthest forward on the driver's side (KIT_SEATS:
     each seat's hip point and recline, noted as the kit makes it), the eye 0.7 m up the seat's back from it, or less
     under a low roof (kept 0.1 m under whatever is straight above), never under 0.45 m */
  const seats=(self.KIT_SEATS||[]).filter(q=>q[2]<-.1&&q[3]<.8).sort((a,b)=>b[0]-a[0]);self.KIT_SEATS=null;
  if(seats.length){const q=seats[0],tr=Math.tan(q[4]),o=[q[0]+.21-.66*tr,q[1]+.45,q[2]];let up=9;
    for(const nm of ['body','bodyG','hood','hoodG','liner']){const Q=out[nm];if(!Q)continue;const p=Q.pos;
      for(let t=0;t<p.length;t+=9){const ax=p[t],az=p[t+2],bx=p[t+3],bz=p[t+5],cx=p[t+6],cz=p[t+8],d=(bz-cz)*(ax-cx)+(cx-bx)*(az-cz);if(Math.abs(d)<1e-12)continue;
        const l1=((bz-cz)*(o[0]-cx)+(cx-bx)*(o[2]-cz))/d,l2=((cz-az)*(o[0]-cx)+(ax-cx)*(o[2]-cz))/d,l3=1-l1-l2;if(l1<0||l2<0||l3<0)continue;
        const y=l1*p[t+1]+l2*p[t+4]+l3*p[t+7]-o[1];if(y>0&&y<up)up=y;}}
    const h=Math.max(.45,Math.min(.7,.45+up-.1));info.eye=[q[0]+.21-h*tr,q[1]+h,q[2]];info.roof=+(.45+up-h).toFixed(3);}
  /* (the builders' own arrays let go: the pieces above are all that's kept) */
  if(typeof KIT_OUT!=='undefined')KIT_OUT.length=0;
  return {msg:{ok:true,info,pieces:out},tr};
}
