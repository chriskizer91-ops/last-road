/* =====================================================================================
   SALT & SAND: the Dyno Bay's garage and dyno as the menu, and the car driven on salt flats and white sand dunes
   with a road through the middle (the world: 51_world's generator, asked first by sas_world.js). The car you drive
   is its full Studio 2, the same one as in the bay: one car on the screen and little else, so it can be all of it.
   No town, no traffic, no police; the challenges, the jobs and the park's laps are left out.
   ===================================================================================== */
DYB.dunes=true;
/* the desert's air (20_daynight envNow): the haze's share, the sky's light's share, the exposure's aim */
DYB.air={fog:.3,amb:.65,key:1.8};
/* (every tread grips on the sand and the salt: the few City Limits didn't list get a dirt-like number) */
for(const t of Object.keys(TREAD_MU)){const m=TREAD_MU[t];if(m.sand==null)m.sand=+(m.dirt*.8).toFixed(2);if(m.salt==null)m.salt=+(m.strip*.95).toFixed(2);}
/* the car you drive, as its Studio 2 (in place of 60_game drawWorldCar's own car): the body and the glass, the hood
   shut with its pad, the engine shuddering with the revs on its mounts, flames from Studio 2's own tips, and at each
   wheel what turns (steered and rolling, at its hub where the physics has it) and what only steers. Every part's
   last-frame matrix is kept, as drawWorldCar keeps them, so TAA sees it move. depth: into a shadow map */
const SAS_PREV=new Float32Array(16);
function drawS2World(t,v,dirt,depth,S){
  const u=CUR.u,M0=carMatrix(t);let Mb=M0;
  const pm=depth?null:(t.drawPrev||(t.drawPrev={}));
  if(pm&&(pm.ro0!==RO[0]||pm.ro2!==RO[2])){const dx=RO[0]-(pm.ro0??RO[0]),dz=RO[2]-(pm.ro2??RO[2]);
    for(const k in pm){const q=pm[k];const M=q&&(q.length===16?q:q.M0);if(M){M[12]-=dx;M[14]-=dz;}}pm.ro0=RO[0];pm.ro2=RO[2];}
  const setM=(key,M)=>{gl.uniformMatrix4fv(u.uM,false,M);if(pm){gl.uniformMatrix4fv(u.uPrevM,false,pm[key]||M);const q=pm[key];if(q&&q.length===16)q.set(M);else pm[key]=M.slice();}};
  if(!depth){carUniformsW(t,v,dirt);gl.uniform1f(u.uMudLocal,1);gl.uniform1f(u.uMudOff,0);gl.uniform1f(u.uPrevOn,1);}
  if(S.pitch)Mb=M4.mul(Mb,M4.mul(M4T(S.fx,S.R,0),M4.mul(M4RZ(S.pitch),M4T(-S.fx,-S.R,0))));
  /* (from the cockpit the car's own windows all but clear: sas_cams) */
  const see=!depth&&u.uSeeX&&cockOn();
  setM('body',Mb);drawMesh(S.body);if(!depth&&S.bodyG){if(see)gl.uniform1f(u.uSeeX,.8);drawMesh(S.bodyG);if(see)gl.uniform1f(u.uSeeX,0);}
  if(S.hood)drawMesh(S.hood);if(!depth&&S.hoodG)drawMesh(S.hoodG);if(S.liner)drawMesh(S.liner);
  /* the engine: a shudder with the revs, big at idle and smoothing out up the rev range (Salt Flats' bay's numbers) */
  if(S.engine){let Me=Mb;
    if(S.pivot&&!depth){const pt=t.pt,e=pt&&pt.e,rpm=pt&&pt.st==='run'?Math.max(0,(pt.we||0)*60/TAU):0,red=(e&&e.redline)||6500,p=S.pivot;
      if(rpm>50){const f=Math.min(rpm/60*2,22),amp=.0019*clamp(1.3-rpm/red*1.4,.3,1.3),w=TAU*f*APP.t,y=amp*(Math.sin(w)+.55*Math.sin(1.37*w+1.3)),a=amp*3.2*Math.sin(.5*w+.4);
        Me=M4.mul(Mb,M4.mul(M4T(p[0],p[1]+y,p[2]),M4.mul(S.trans?M4RZ(a):M4RX(a),M4T(-p[0],-p[1],-p[2]))));}}
    setM('eng',Me);drawMesh(S.engine);}
  if(!depth&&v&&v.flame>.04&&S.tips)for(const tp of S.tips){
    const up=Math.abs(tp.d[1])>.9?[1,0,0]:[0,1,0],rr=V3.norm(V3.cross(tp.d,up)),uu=V3.cross(rr,tp.d),k=Math.min(1,v.flame),fl=(.12+.42*k*(v.flameL||.8))*(.85+.3*Math.random()),fr=(tp.r||.04)*(.8+.5*k);
    const Mf=M4.mul(Mb,M4.mul(M4.basis(tp.p,tp.d,uu,rr),M4S(fl,fr,fr)));if(!Mf.every(Number.isFinite))continue;
    gl.uniformMatrix4fv(u.uM,false,Mf);gl.uniformMatrix4fv(u.uPrevM,false,Mf);drawMesh(flameMesh());}
  const WS=t.wheels;
  for(let k=0;k<WS.length;k++){const w=WS[k],s=w.hp[2]<0?-1:1,st=w.front?t.steer:0;if(!depth)gl.uniform1f(u.uMudOff,w.R);
    const x=w.hp[0]+t.cg[0],y=w.hp[1]-w.len+t.cg[1],z=w.hp[2],key='s2w'+k,p=pm&&pm[key],dA=p?clamp(w.ang-p.ang,-.35,.35):0;
    /* what turns */
    if(pm&&p)SAS_PREV.set(wheelMat(p.M0,x,y,z,p.st,s,w.ang-dA));
    gl.uniformMatrix4fv(u.uM,false,wheelMat(M0,x,y,z,st,s,w.ang));if(pm)gl.uniformMatrix4fv(u.uPrevM,false,p?SAS_PREV:WHM);
    drawMesh(w.front?S.wheel:S.wheelR);
    /* what only steers */
    const br=w.front?S.brake:S.brakeR;
    if(br){if(pm&&p)SAS_PREV.set(wheelMat(p.M0,x,y,z,p.st,s,0));
      gl.uniformMatrix4fv(u.uM,false,wheelMat(M0,x,y,z,st,s,0));if(pm)gl.uniformMatrix4fv(u.uPrevM,false,p?SAS_PREV:WHM);drawMesh(br);}
    if(pm){if(p){p.M0.set(M0);p.st=st;p.ang=w.ang;}else pm[key]={M0:M0.slice(),st,ang:w.ang};}}
  if(!depth){gl.uniform1f(u.uMudOff,0);gl.uniform1f(u.uMudLocal,0);gl.uniform1f(u.uPrevOn,0);gl.uniform1f(u.uDirt,0);gl.uniform1f(u.uLiv,0);gl.uniform1f(u.uLamps,0);gl.uniform1f(u.uBrake,0);gl.uniform3f(u.uGlow,0,0,0);}
  return S.tris;
}
/* ---------- Cinematic (Salt Flats' camera crew, on the game's camera: 60_game camUpdate asks here) ----------
   A camera standing still beside the way the car is going, well ahead of it (about eight seconds of driving at the
   speed it's doing, 60 m to a kilometre), turning to follow it as it comes, passes and goes, and zooming to keep it
   framed: the car about a quarter of the picture's height, a wide lens close by and a long one far off. Each shot runs
   about fourteen seconds whatever the speed; once the car is well past, the next camera is set up further on, most
   often on the other side, at another height. Stopped, it stands a little way off to one side. On the dunes it stands
   on the sand, raised until it can see over the ridges to the car and to where the car will pass it. Heard from where
   it stands (the lab's Trackside), louder close by, the pitch up as the car comes and down as it goes. */
const CINE={p:[0,0,0],dir:[1,0,0],look:[0,0,0],fov:30,ok:false,side:1,d:10,cut:false,near:.3};
const CINE_H=[.6,1.2,1.8,3.2,6];
/* whether the ground hides b from a (a few points along the line, each against the ground under it) */
function cineBlocked(a,b){for(let k=1;k<12;k++){const f=k/12,x=a[0]+(b[0]-a[0])*f,y=a[1]+(b[1]-a[1])*f,z=a[2]+(b[2]-a[2])*f;if(RANCH.W.heightAt(x,z)>y-.3)return true;}return false;}
function cineSpot(t){
  const v=t.speed,M=t.M;let dir=norm2([M[0],0,M[6]]);if(v>2&&t.v[0]*t.v[0]+t.v[2]*t.v[2]>1)dir=norm2([t.v[0],0,t.v[2]]);
  const right=[-dir[2],0,dir[0]];CINE.side=Math.random()<.75?-CINE.side:CINE.side;
  const ahead=v<2?0:clamp(v*8.2,60,1050)*(.8+Math.random()*.4),lat=(v<2?11:7+Math.random()*11)*CINE.side;let h=CINE_H[(Math.random()*CINE_H.length)|0];
  const x=t.p[0]+dir[0]*ahead+right[0]*lat,z=t.p[2]+dir[2]*ahead+right[2]*lat,gy=RANCH.W.heightAt(x,z),car=[t.p[0],t.p[1]+.8,t.p[2]],
    pass=[t.p[0]+dir[0]*ahead,RANCH.W.heightAt(t.p[0]+dir[0]*ahead,t.p[2]+dir[2]*ahead)+.8,t.p[2]+dir[2]*ahead];
  let p=[x,gy+h,z];for(let k=0;k<10&&(cineBlocked(p,car)||cineBlocked(p,pass));k++){h+=3;p=[x,gy+h,z];}
  CINE.p=p;CINE.dir=dir;CINE.look=car;CINE.ok=true;CINE.cut=true;viewCut();}
function cineStep(t,dt,cut){
  if(!CINE.ok||cut)cineSpot(t);
  let rel=sub2(t.p,CINE.p),along=dot2(rel,CINE.dir),d=len(rel);const v=t.speed;
  /* the car well past (or gone somewhere else, or parked far off): the next camera */
  if(along>clamp(v*6,60,800)||d>2500||v<2&&d>70){cineSpot(t);}
  const k=CINE.cut?1:1-Math.exp(-dt*7),L=CINE.look,tg=[t.p[0],t.p[1]+.8,t.p[2]];CINE.look=[L[0]+(tg[0]-L[0])*k,L[1]+(tg[1]-L[1])*k,L[2]+(tg[2]-L[2])*k];
  CINE.d=len(sub2(CINE.look,CINE.p));
  /* the zoom: the car about a quarter of the picture's height, whatever the distance */
  const want=clamp(2*Math.atan(3.6/Math.max(CINE.d,1))*180/PI,1.2,55);CINE.fov=CINE.cut?want:CINE.fov+(want-CINE.fov)*(1-Math.exp(-dt*1.5));CINE.cut=false;
  /* (on the long lens the near plane moves out with the car, so the ground keeps its depth a quarter of a mile off) */
  CINE.near=clamp(CINE.d*.12,.25,120);
  return {eye:CINE.p.slice(),fwd:norm2(sub2(CINE.look,CINE.p)),up:[0,1,0],fov:CINE.fov*PI/180};
}
/* ---------- the drones: 100 ft (30.5 m) up, looking down at the car ----------
   Four hold their station round it, out 22 m: ahead of it (lead), behind it (tail), off its left and off its right.
   Where "ahead" is comes from the way the car is going, turned slowly (about a second and a half to come round), so a
   spin or a slide doesn't whip the drone round: it swings round after the car like a pilot would. The fifth, Drone
   orbit, drifts round the car once every 48 seconds whatever the car does (spins, slides, jumps), easing a little in
   and out and up and down as it goes. All of them keep up at any speed, hover with a slow bob of a few centimetres,
   bank a touch into their own turns, stay at least 6 m over the sand, and look at the car (a little ahead of it the
   faster it goes). */
const DRONE={yaw:null,yawV:0,off:null,pv:[0,0,0],a:0,t:0},DRONE_H=30.5,DRONE_R=22;
const DRONE_AT={lead:0,tail:PI,left:PI/2,right:-PI/2};
function droneStep(t,dt,cut,kind){
  const sp=t.speed,M=t.M;let dir=norm2([M[0],0,M[6]]);if(sp>3&&t.v[0]*t.v[0]+t.v[2]*t.v[2]>1)dir=norm2([t.v[0],0,t.v[2]]);
  const ty=Math.atan2(-dir[2],dir[0]);
  if(DRONE.yaw===null||cut){if(DRONE.yaw===null)DRONE.a=ty+PI*.8;DRONE.yaw=ty;DRONE.yawV=0;DRONE.off=null;}
  let d=ty-DRONE.yaw;while(d>PI)d-=TAU;while(d<-PI)d+=TAU;[DRONE.yaw,DRONE.yawV]=springTo(DRONE.yaw,DRONE.yawV,DRONE.yaw+d,1.4,dt);
  DRONE.t+=dt;
  const orbit=kind==='orbit';if(orbit)DRONE.a+=dt*TAU/48;
  const ang=orbit?DRONE.a:DRONE.yaw+(DRONE_AT[kind]||0),r=orbit?DRONE_R+4*Math.sin(DRONE.t/23):DRONE_R,h=DRONE_H+(orbit?3.5*Math.sin(DRONE.t/31):0);
  const off=[Math.cos(ang)*r,h,-Math.sin(ang)*r];
  if(!DRONE.off){DRONE.off=off.slice();DRONE.pv=[0,0,0];}
  for(let k=0;k<3;k++){const q=springTo(DRONE.off[k],DRONE.pv[k],off[k],orbit?2.4:1.8,dt);DRONE.off[k]=q[0];DRONE.pv[k]=q[1];}
  const T=DRONE.t,eye=[t.p[0]+DRONE.off[0]+.18*Math.sin(T*.7)+.08*Math.sin(T*1.9),t.p[1]+DRONE.off[1]+.12*Math.sin(T*.9+1),t.p[2]+DRONE.off[2]+.18*Math.sin(T*.6+2)];
  const gy=RANCH.W.heightAt(eye[0],eye[2])+6;if(eye[1]<gy)eye[1]=gy;
  const lead=clamp(sp*.25,0,8),at=[t.p[0]+dir[0]*lead,t.p[1]+.5,t.p[2]+dir[2]*lead],fwd=norm2(sub2(at,eye));
  const rt=V3.norm(V3.cross(fwd,[0,1,0])),bank=clamp(-(orbit?TAU/48:DRONE.yawV)*.09,-.12,.12),up=V3.norm([rt[0]*bank,1,rt[2]*bank]);
  return {eye,fwd,up,fov:orbit?.7:.74};
}
/* ---------- the low drone: 50 ft (15 m) up, a slower Cinematic ----------
   Set up ahead of the car and off to one side, it flies the same way at half the car's speed (easing to it over a
   couple of seconds when the car speeds up or slows), so the car takes its time catching it up, comes by below it
   and draws away: a shot of about 25 seconds, the drone drifting in toward the car's line as it goes. It turns after
   the car and zooms to keep it framed (the car about a fifth of the picture's height, more of the country round it
   than Cinematic), both lazier than Cinematic's. Once the car is well past (or has turned back, or gone far off), the
   next shot, most often from the other side, a little higher or lower. Stopped, it hangs about 25 m off, swaying,
   and comes round to the other side every half minute. Over the dunes it climbs until it can see the car, and comes
   down again slowly. Heard from where it flies. */
const LOWD={o:[0,0,0],s:0,sp:0,dir:[1,0,0],lat:15,lat1:15,h:15,y:0,raise:0,look:[0,0,0],fov:30,ok:false,side:1,t:0,shot:0,cut:false,near:.3,p:[0,0,0],vel:[0,0,0]};
const LOWD_F=.5;
function lowSpot(t){
  const v=t.speed,M=t.M;let dir=norm2([M[0],0,M[6]]);if(v>2&&t.v[0]*t.v[0]+t.v[2]*t.v[2]>1)dir=norm2([t.v[0],0,t.v[2]]);
  LOWD.side=Math.random()<.75?-LOWD.side:LOWD.side;
  const rv=v*(1-LOWD_F),ahead=v<2?0:clamp(rv*13,45,500)*(.85+Math.random()*.3);
  LOWD.dir=dir;LOWD.o=[t.p[0]+dir[0]*ahead,0,t.p[2]+dir[2]*ahead];LOWD.s=0;LOWD.sp=LOWD_F*Math.max(0,v);LOWD.shot=0;
  LOWD.lat=(v<2?25:12+Math.random()*16)*LOWD.side;LOWD.lat1=v<2?LOWD.lat:LOWD.lat*(.55+Math.random()*.3);
  LOWD.h=13+Math.random()*5;LOWD.raise=0;LOWD.y=null;LOWD.look=[t.p[0],t.p[1]+.6,t.p[2]];LOWD.ok=true;LOWD.cut=true;viewCut();}
function lowStep(t,dt,cut,again){
  if(!LOWD.ok||cut)lowSpot(t);
  const v=t.speed,dir=LOWD.dir,right=[-dir[2],0,dir[0]],vAlong=t.v[0]*dir[0]+t.v[2]*dir[2];
  LOWD.t+=dt;LOWD.shot+=dt;
  LOWD.sp+=(LOWD_F*Math.max(0,vAlong)-LOWD.sp)*(1-Math.exp(-dt*.5));LOWD.s+=LOWD.sp*dt;
  LOWD.lat+=(LOWD.lat1-LOWD.lat)*(1-Math.exp(-dt/12));
  const T=LOWD.t,sway=v<2?3*Math.sin(T/3.2):0,lat=LOWD.lat+sway;
  const x=LOWD.o[0]+dir[0]*LOWD.s+right[0]*lat,z=LOWD.o[2]+dir[2]*LOWD.s+right[2]*lat,gy=RANCH.W.heightAt(x,z);
  const car=[t.p[0],t.p[1]+.6,t.p[2]];
  /* its height: over the ground under it or the car, whichever is higher; climbing (6 m a second) while the sand hides the car */
  const wantY=Math.max(gy,t.p[1]-.5)+LOWD.h+LOWD.raise;LOWD.y=LOWD.y===null?wantY:LOWD.y+(wantY-LOWD.y)*(1-Math.exp(-dt*1.1));
  let eye=[x+.15*Math.sin(T*.7),Math.max(LOWD.y,gy+4)+.1*Math.sin(T*.9+1),z+.15*Math.sin(T*.6+2)];
  if(cineBlocked(eye,car))LOWD.raise=Math.min(LOWD.raise+dt*6,25);else LOWD.raise=Math.max(LOWD.raise-dt*.8,0);
  const rel=sub2(t.p,eye),along=rel[0]*dir[0]+rel[2]*dir[2],d=len(rel),rv=Math.max(v-LOWD.sp,0);
  /* the car well past, turned back, gone far off, or stopped a while: the next shot */
  if(along>Math.max(rv*10,35)||d>700||vAlong<-3&&d>60||v<2&&(d>90||LOWD.shot>30)){lowSpot(t);if(!again)return lowStep(t,0,false,true);}
  const k=LOWD.cut?1:1-Math.exp(-dt*3.5),L=LOWD.look;LOWD.look=[L[0]+(car[0]-L[0])*k,L[1]+(car[1]-L[1])*k,L[2]+(car[2]-L[2])*k];
  const dl=len(sub2(LOWD.look,eye));
  const want=clamp(2*Math.atan(4.5/Math.max(dl,1))*180/PI,3,62);
  LOWD.fov=LOWD.cut?want:Math.max(LOWD.fov+(want-LOWD.fov)*(1-Math.exp(-dt*.8)),want*.75);LOWD.cut=false;
  LOWD.near=clamp(dl*.12,.25,60);LOWD.p=eye;LOWD.vel=[dir[0]*LOWD.sp,0,dir[2]*LOWD.sp];
  return {eye,fwd:norm2(sub2(LOWD.look,eye)),up:[0,1,0],fov:LOWD.fov*PI/180};
}
/* how the camera hears the car (60_game soundUpdate's geometry): from the camera, the pan where it is on the picture, the
   pitch its speed toward or away from the camera gives (P where the camera is, pv how it's moving) */
function cineSound(t,right,P=CINE.p,pv=[0,0,0]){
  const toC=sub2(P,t.p),d=len(toC),u=[toC[0]/Math.max(d,1e-3),toC[1]/Math.max(d,1e-3),toC[2]/Math.max(d,1e-3)],F=mcol(t.M,0);
  const vr=(t.v[0]-pv[0])*u[0]+(t.v[1]-pv[1])*u[1]+(t.v[2]-pv[2])*u[2];
  return {geo:{dist:clamp(d*.6,2,60),pan:clamp(-dot2(u,right)*.9,-1,1),rear:clamp(.5-.5*dot2(u,F),0,1)*.6+.4},dop:clamp(343/(343-vr),.65,1.45)};}
/* the start: free play, no traffic, no police; the bay's Drive button out onto the road; the bar's one chip (all a
   phone has up there) says where it goes: Bay while you drive, Drive in the menu */
function sasBoot(){APP.traffic=false;APP.police=false;camKeep();
  const b=$('sasDrive');if(b)b.addEventListener('click',()=>{b.blur();showFull(false);closeMenu();});
  const chip=()=>{const c=$('menuBtn');if(!c)return;const w=GAME.state==='drive'?'Bay':'Drive';if(c.textContent!==w)c.textContent=w;};chip();setInterval(chip,250);}
