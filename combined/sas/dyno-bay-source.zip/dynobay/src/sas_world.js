/* (Salt & Sand) THE WORLD AS SALT AND SAND, in place of City & Country's: a two-lane blacktop east and west along
   z = 0, the whole way across; north of it (z < 0) the salt flats, flat and hard (the physics' "strip", the salt
   crust's look); south of it white gypsum dunes, rising out of the flat sand beside the road to ridges about ten
   metres tall a hundred metres from it. The wind that made them blows from the west: each ridge runs north and south,
   wavering, a long gentle slope up its west side to a rounded crest, then the slip face, steep (about 33 degrees on
   the big ones) down its east side. Ridge by ridge they differ in size, and along each one the crest rises and falls,
   with flat sand between. Everything else City & Country has (the town, the roads, farms, creeks, trees, the park)
   is left out: core, baseAt, the chunks' statics and the far tiles ask here first. */
const DN={hw:3.9,sh:1.1,lam:150,amax:12};
function duneH(x,z){
  const ramp=sst(12,75,z);if(ramp<=0)return 0;
  /* (the ridges waver: where along x each one stands drifts with z, slowly and a little quicker) */
  const wx=(fbm(x/620+3.1,z/620-1.7,2,901)-.5)*160+Math.sin(z/97+fbm(x/300,z/300,1,903)*3)*24+(fbm(x/170,z/170,2,902)-.5)*22;
  const u=(x+wx)/DN.lam,n=Math.floor(u),f=u-n;
  /* how big this ridge is here: some big, some small, the crest rising and falling along it */
  const big=vn(z/320+n*.71,n*1.37,911),along=vn(z/85+n*5.1,n*.3+7,913);
  const A=DN.amax*(.2+.8*sst(.2,.75,big))*(.55+.45*along);
  /* up the west slope to the crest, then down the slip face */
  const c=.82;let p;
  if(f<c){const t=f/c;p=t*t*(3-2*t);}else{const t=(f-c)/(1-c);p=1-t*t*(3-2*t);}
  const base=(fbm(x/900+5.5,z/900+1.1,2,915)-.5)*2.4,small=(vn(x/26+u*.3,z/26,916)-.5)*.7*(.3+p);
  return (base+A*p+small)*ramp;
}
function duneCore(x,z,o){
  const az=Math.abs(z),e=DN.hw+DN.sh;
  /* the road and its shoulders level; the salt a few centimetres under them; the sand flat beside them, then the dunes */
  const h=(z>=0?duneH(x,z):-.06*sst(e+.5,e+5,az))+rimAt(x,z);
  const code=az<DN.hw?SF.asphalt:az<e?SF.gravel:z<0?SF.strip:SF.sand;
  /* (under the road too, the ground is salt or sand, so the far tiles show no stripe where it runs) */
  const sand=sst(-1.5,1.5,z);
  o.h=h;o.code=code;o.grass=0;o.rock=0;o.mud=0;o.salt=1-sand;o.sand=sand;o.ramp=0;o.wet=0;o.wl=h;o.B=0;o.rk=0;o.k=0;o.tm=0;o.tin=0;
  return o;
}
