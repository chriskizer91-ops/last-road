/* =====================================================================================
   SALT & SAND'S CAMERAS, CHOSEN: which cameras the camera button (C, or CAM on a phone) goes through, and five more.
   - The list (Settings, Cameras): each camera on or off; the camera button and the Drive tab's camera row only go
     through the ones that are on (one always stays on). Each has its Director time: how long the Director holds it.
   - The Director (on or off): switches by itself between the cameras that are on, each held for its own time, never
     the same one twice running (nor back to the one before, when there are three or more on).
   - Jump cam (on or off): when the car leaves the ground properly (a fifth of a second in the air, half a metre up,
     faster than 18 mph) it cuts to a camera standing off to the side of where the jump goes, low, looking up at it,
     and cuts back to your camera once the car has been down for 0.8 s. Heard from where it stands.
   - Cockpit: the driver's seat, in Studio 2's own cabin (the eye placed from the seat the model has, s2make), the
     cabin fixed round you, the head steadied a touch over the bumps; the windows clear from inside.
   - Wheel cam: fixed off the car's side, the whole side of the car in the picture, at wheel height; it goes where the
     car goes and turns as it turns. Tapped again on the Drive tab: the other side.
   - Tracking car: a camera car running alongside, low, its arm sweeping slowly from the front quarter round to the
     rear quarter and back (26 s), a longer lens: the car commercial's shot.
   - Roadside: a camera on the ground a few metres off the car's line, ahead of it, a wide lens panning round as the
     car blasts past; then the next one ahead. Heard from where it stands.
   - Drone follow: 50 ft (15.2 m) up, 12 m behind and keeping right up with the car, drifting a little side to side
     and bobbing as a drone does.
   ===================================================================================== */
/* the order they're listed in (CAMS' own numbers: what the save keeps) */
const CAM_ORDER=[0,1,2,11,12,13,14,3,9,10,8,4,5,6,7];
const CAM_TIMES=[4,6,8,10,12,14,16,20,25,30,40,60];
const CAM_DEF={on:[0,2,11,12,13,14,3,9,10,8],t:{0:10,1:10,2:8,11:12,12:8,13:13,14:8,3:14,9:20,10:10,8:16,4:8,5:8,6:8,7:8},dir:false,jump:true};
const CAMSET=(()=>{const o=JSON.parse(JSON.stringify(CAM_DEF));let s=null;try{s=JSON.parse(store.get('cams','null'));}catch(e){}
  if(s&&typeof s==='object'){if(Array.isArray(s.on))o.on=s.on.map(Number).filter(i=>CAM_ORDER.includes(i));
    if(s.t)for(const k in s.t)if(CAM_TIMES.includes(+s.t[k]))o.t[k]=+s.t[k];o.dir=!!s.dir;o.jump=s.jump!==false;}
  if(!o.on.length)o.on=[0];return o;})();
const camSave=()=>store.set('cams',JSON.stringify(CAMSET));
const camList=()=>CAM_ORDER.filter(i=>CAMSET.on.includes(i));
const DIR={t:0,prev:-1};
function camPick(i){if(i===APP.cam&&CAMS[i]==='Wheel cam')WHEEL.side=-WHEEL.side;APP.cam=i;CAM.cut=true;DIR.t=0;saveGame();say(CAMS[i]+' camera',1.2);}
function camNext(){const L=camList(),k=L.indexOf(APP.cam);APP.cam=L[(k+1)%L.length];CAM.cut=true;DIR.t=0;saveGame();say(CAMS[APP.cam]+' camera',1.2);camRowSync();}
/* the camera you were on switched off: the first one that's on */
function camKeep(){if(!CAMSET.on.includes(APP.cam)){APP.cam=camList()[0];CAM.cut=true;saveGame();}}
/* the Drive tab's row: the cameras that are on, and the Director */
function camRowBuild(){const h=$('mCam');if(!h)return;h.innerHTML='';
  segButtons(h,[...camList().map(i=>[i,CAMS[i]]),['dir','Director']],v=>{
    if(v==='dir'){CAMSET.dir=!CAMSET.dir;DIR.t=0;camSave();say(CAMSET.dir?'Director on':'Director off',1.2);return;}camPick(+v);});
  camRowSync();}
function camRowSync(){const h=$('mCam');if(!h)return;for(const el of h.children)el.setAttribute('aria-pressed',String(el.dataset.v==='dir'?CAMSET.dir:+el.dataset.v===APP.cam));}
/* Settings: the Cameras drop-down */
function camSetBuild(){const L=$('sCamList');if(!L)return;L.innerHTML='';
  for(const i of CAM_ORDER){const r=document.createElement('div');r.className='camrow';r.dataset.i=i;
    r.innerHTML=`<button type="button" class="sw"></button><span class="nm">${CAMS[i]}</span><span class="tm"><button type="button" class="dn" aria-label="Shorter">−</button><b></b><button type="button" class="upb" aria-label="Longer">+</button></span>`;
    r.querySelector('.sw').addEventListener('click',()=>{const on=CAMSET.on.includes(i);if(on&&CAMSET.on.length<=1){say('One camera stays on',1.4);return;}
      CAMSET.on=on?CAMSET.on.filter(q=>q!==i):[...CAMSET.on,i];camSave();camKeep();camRowBuild();camSetSync();});
    const step=d=>{const T=CAM_TIMES;let k=T.indexOf(CAMSET.t[i]||10);if(k<0)k=3;CAMSET.t[i]=T[clamp(k+d,0,T.length-1)];camSave();camSetSync();};
    r.querySelector('.dn').addEventListener('click',()=>step(-1));r.querySelector('.upb').addEventListener('click',()=>step(1));L.appendChild(r);}
  for(const [id,key] of [['sDir','dir'],['sJump','jump']]){const h=$(id);if(!h)continue;h.innerHTML='';
    segButtons(h,[[1,'On'],[0,'Off']],v=>{CAMSET[key]=!!+v;if(key==='dir')DIR.t=0;camSave();});}
  camSetSync();}
function camSetSync(){
  for(const r of document.querySelectorAll('#sCamList .camrow')){const i=+r.dataset.i,on=CAMSET.on.includes(i),b=r.querySelector('.sw');
    r.classList.toggle('on',on);b.textContent=on?'On':'Off';b.setAttribute('aria-pressed',String(on));r.querySelector('b').textContent=(CAMSET.t[i]||10)+' s';}
  for(const [id,key] of [['sDir','dir'],['sJump','jump']]){const h=$(id);if(h)for(const el of h.children)el.setAttribute('aria-pressed',String(!!+el.dataset.v===CAMSET[key]));}
  camRowSync();}

/* ---------- the Director and the jump cam (each frame, before the camera's own view) ---------- */
const JUMP={on:false,p:[0,0,0],look:[0,0,0],fov:1,t:0,land:0,cut:false,cool:0,n:0};
function camAuto(t,dt){
  const drive=GAME.state==='drive'&&!APP.orbit&&!CAM.rear;JUMP.cool=Math.max(0,JUMP.cool-dt);
  if(JUMP.on){if(!drive||JUMP.land>.8||JUMP.t>5){JUMP.on=false;JUMP.cool=1.2;CAM.cut=true;}else return jumpView(t,dt);}
  if(!drive)return null;
  if(CAMSET.jump&&!JUMP.cool&&t.air&&t.airT>.2&&t.speed>8){const gy=RANCH.W.heightAt(t.p[0],t.p[2]);
    if(t.p[1]-t.c.hcg-gy>.5){jumpStart(t);CAM.yaw=null;CAM.off=null;CAM.fq=null;return jumpView(t,0);}}
  if(CAMSET.dir){DIR.t+=dt;if(DIR.t>=(CAMSET.t[APP.cam]||10)){DIR.t=0;let L=camList().filter(i=>i!==APP.cam);if(L.length>1)L=L.filter(i=>i!==DIR.prev);
    if(L.length){DIR.prev=APP.cam;APP.cam=L[(Math.random()*L.length)|0];CAM.cut=true;camRowSync();}}}
  return null;}
function jumpStart(t){
  const v=t.v,hs=Math.hypot(v[0],v[2]),hd=hs>1?[v[0]/hs,0,v[2]/hs]:norm2([t.M[0],0,t.M[6]]),right=[-hd[2],0,hd[0]],W=RANCH.W;
  /* where it'll be in half a second: the camera off to one side of that, a little behind it, low */
  const T=.5,mid=[t.p[0]+v[0]*T,0,t.p[2]+v[2]*T];mid[1]=Math.max(t.p[1]+v[1]*T-4.9*T*T,W.heightAt(mid[0],mid[2])+.8);
  const s0=Math.random()<.5?1:-1;let best=null;
  for(const s of [s0,-s0]){for(const h of [1.2,2.5,4,6]){const dd=11+Math.random()*3,x=mid[0]+right[0]*dd*s-hd[0]*2,z=mid[2]+right[2]*dd*s-hd[2]*2,e=[x,W.heightAt(x,z)+h,z];
      if(!cineBlocked(e,mid)&&!cineBlocked(e,t.p)){best=e;break;}}if(best)break;}
  if(!best){const x=mid[0]+right[0]*12*s0,z=mid[2]+right[2]*12*s0;best=[x,Math.max(W.heightAt(x,z)+6,mid[1]+2),z];}
  JUMP.p=best;JUMP.look=[t.p[0],t.p[1],t.p[2]];JUMP.on=true;JUMP.t=0;JUMP.land=0;JUMP.cut=true;JUMP.n++;viewCut();}
function jumpView(t,dt){
  JUMP.t+=dt;if(t.air)JUMP.land=0;else JUMP.land+=dt;
  const eye=JUMP.p,k=JUMP.cut?1:1-Math.exp(-dt*10),L=JUMP.look;JUMP.look=[L[0]+(t.p[0]-L[0])*k,L[1]+(t.p[1]-L[1])*k,L[2]+(t.p[2]-L[2])*k];
  const d=len(sub2(JUMP.look,eye)),want=clamp(2*Math.atan(4.5/Math.max(d,1)),.45,1.05);
  JUMP.fov=JUMP.cut?want:JUMP.fov+(want-JUMP.fov)*(1-Math.exp(-dt*5));JUMP.cut=false;
  return {eye:eye.slice(),fwd:norm2(sub2(JUMP.look,eye)),up:[0,1,0],fov:JUMP.fov};}

/* ---------- Cockpit ---------- */
const COCK={F:null,U:null,seat:false};
const cockOn=()=>CAMS[APP.cam]==='Cockpit'&&GAME.state==='drive'&&!APP.orbit&&!CAM.rear&&!JUMP.on;
function cockStep(t,dt,cut){
  const S=s2For(t.bi),M=t.M,D=carD(t),I=S&&S.info;let q,pa=0;
  const body=p=>add(t.p,mvec(M,[p[0]-t.cg[0],p[1]-t.cg[1],p[2]]));
  if(I&&I.eye){pa=S.pitch||0;const e=I.eye,c=Math.cos(pa),s=Math.sin(pa),fx=S.fx,R=S.R;q=[fx+(e[0]-fx)*c-(e[1]-R)*s,R+(e[0]-fx)*s+(e[1]-R)*c,e[2]];COCK.seat=true;}
  else{const u=D.uFa+D.B.wb*.15;q=[D.X(u),D.belt(u)+.25,0];COCK.seat=false;}
  const eye=body(q),F=mvec(M,[Math.cos(pa),Math.sin(pa),0]),U=mvec(M,[-Math.sin(pa),Math.cos(pa),0]);
  if(!COCK.F||cut){COCK.F=F;COCK.U=U;}const k=1-Math.exp(-dt*22);
  COCK.F=norm2(madd(COCK.F,sub2(F,COCK.F),k));COCK.U=norm2(madd(COCK.U,sub2(U,COCK.U),k));
  /* (looking a touch down the road, over the wheel) */
  const dn=.07,fwd=norm2(madd(COCK.F,COCK.U,-dn)),up=norm2(madd(COCK.U,COCK.F,dn));
  return {eye,fwd,up,fov:1};}

/* ---------- Wheel cam ---------- */
const WHEEL={side:-1};
function wheelStep(t,dt,cut){
  const M=t.M,D=carD(t),S=s2For(t.bi),Z=mcol(M,2);let zh=[Z[0],0,Z[2]];
  if(Math.hypot(zh[0],zh[2])<.3){const F=mcol(M,0);zh=[-F[2],0,F[0]];}zh=norm2(zh);
  const cx=S?S.fx-S.wb/2:0,C=add(t.p,mvec(M,[cx-t.cg[0],.62-t.cg[1],0]));
  /* (far enough that the near side of the car, half its width nearer, fits nose to tail with 0.7 m to spare) */
  const asp=Math.max(1,innerWidth/Math.max(1,innerHeight)),fov=.8,d=clamp((S?S.tw+.28:.95)+(D.L/2+.7)/(Math.tan(fov/2)*asp),3.5,9);
  const eye=[C[0]+zh[0]*WHEEL.side*d,C[1]+.1,C[2]+zh[2]*WHEEL.side*d],gy=RANCH.W.heightAt(eye[0],eye[2])+.3;if(eye[1]<gy)eye[1]=gy;
  return {eye,fwd:norm2(sub2([C[0],C[1]+.05,C[2]],eye)),up:[0,1,0],fov};}

/* ---------- Tracking car ---------- */
const TRK={yaw:null,yawV:0,off:null,pv:[0,0,0],t:0,side:1,ph:0};
function trackStep(t,dt,cut){
  const sp=t.speed,M=t.M,D=carD(t),kl=Math.sqrt(D.L/4.92);let dir=norm2([M[0],0,M[6]]);if(sp>3&&t.v[0]*t.v[0]+t.v[2]*t.v[2]>1)dir=norm2([t.v[0],0,t.v[2]]);
  const ty=Math.atan2(-dir[2],dir[0]);
  if(TRK.yaw===null||cut){TRK.yaw=ty;TRK.yawV=0;TRK.off=null;TRK.side=-TRK.side;TRK.ph=Math.random()*TAU;TRK.t=0;}
  let d=ty-TRK.yaw;while(d>PI)d-=TAU;while(d<-PI)d+=TAU;[TRK.yaw,TRK.yawV]=springTo(TRK.yaw,TRK.yawV,TRK.yaw+d,2.2,dt);
  TRK.t+=dt;
  /* the arm's angle from the car's nose: 90 degrees (square on) give or take 54, round and back in 26 s */
  const th=PI/2+.95*Math.sin(TRK.t*TAU/26+TRK.ph),a=TRK.yaw+TRK.side*th,r=8.5*kl+clamp(sp*.04,0,3);
  const ex=t.p[0]+Math.cos(a)*r,ez=t.p[2]-Math.sin(a)*r,gy=RANCH.W.heightAt(ex,ez);
  const off=[Math.cos(a)*r,Math.max(gy+1.05,t.p[1]+.3)-t.p[1],-Math.sin(a)*r];
  if(!TRK.off){TRK.off=off.slice();TRK.pv=[0,0,0];}
  for(let k=0;k<3;k++){const q=springTo(TRK.off[k],TRK.pv[k],off[k],k===1?3:2.4,dt);TRK.off[k]=q[0];TRK.pv[k]=q[1];}
  const eye=add(t.p,TRK.off),g2=RANCH.W.heightAt(eye[0],eye[2])+.6;if(eye[1]<g2)eye[1]=g2;
  const at=[t.p[0]+dir[0]*.8,t.p[1]+.1,t.p[2]+dir[2]*.8];
  return {eye,fwd:norm2(sub2(at,eye)),up:[0,1,0],fov:.62};}

/* ---------- Roadside ---------- */
const RSIDE={p:[0,0,0],look:[0,0,0],fov:1,ok:false,side:1,shot:0,cut:false,dir:[1,0,0],n:0};
function roadSpot(t){
  const v=t.speed,M=t.M,W=RANCH.W;let dir=norm2([M[0],0,M[6]]);if(v>2&&t.v[0]*t.v[0]+t.v[2]*t.v[2]>1)dir=norm2([t.v[0],0,t.v[2]]);
  const right=[-dir[2],0,dir[0]];RSIDE.side=Math.random()<.7?-RSIDE.side:RSIDE.side;
  const ahead=v<2?6:clamp(v*2.8,16,140)*(.85+Math.random()*.3),pass=[t.p[0]+dir[0]*ahead,0,t.p[2]+dir[2]*ahead];pass[1]=W.heightAt(pass[0],pass[2])+.7;
  const car=[t.p[0],t.p[1]+.4,t.p[2]];let best=null;
  for(let k=0;k<6&&!best;k++){const s=k<3?RSIDE.side:-RSIDE.side,lat=(3.6+Math.random()*2.6)*s,x=pass[0]+right[0]*lat,z=pass[2]+right[2]*lat,gy=W.heightAt(x,z);
    for(let h=.35;h<=2.7&&!best;h+=.75){const e=[x,gy+h,z];if(!cineBlocked(e,pass)&&!cineBlocked(e,car))best=e;}}
  if(!best){const x=pass[0]+right[0]*5*RSIDE.side,z=pass[2]+right[2]*5*RSIDE.side;best=[x,W.heightAt(x,z)+2.7,z];}
  RSIDE.p=best;RSIDE.dir=dir;RSIDE.look=car;RSIDE.ok=true;RSIDE.cut=true;RSIDE.shot=0;RSIDE.n++;viewCut();}
function roadStep(t,dt,cut,again){
  if(!RSIDE.ok||cut)roadSpot(t);
  RSIDE.shot+=dt;const v=t.speed,dir=RSIDE.dir,vAlong=t.v[0]*dir[0]+t.v[2]*dir[2],eye=RSIDE.p,rel=sub2(t.p,eye),along=rel[0]*dir[0]+rel[2]*dir[2],d=len(rel);
  /* the car well past, turned back, far off, or stopped a while: the next one */
  if(along>Math.max(22,v*1.1)||d>260||vAlong<-3&&d>40||v<2&&RSIDE.shot>12){roadSpot(t);if(!again)return roadStep(t,0,false,true);}
  const car=[t.p[0],t.p[1]+.25,t.p[2]],k=RSIDE.cut?1:1-Math.exp(-dt*9),L=RSIDE.look;RSIDE.look=[L[0]+(car[0]-L[0])*k,L[1]+(car[1]-L[1])*k,L[2]+(car[2]-L[2])*k];
  const dl=len(sub2(RSIDE.look,eye)),want=clamp(2*Math.atan(6.5/Math.max(dl,.5)),.6,1.15);
  RSIDE.fov=RSIDE.cut?want:RSIDE.fov+(want-RSIDE.fov)*(1-Math.exp(-dt*4));RSIDE.cut=false;
  return {eye:eye.slice(),fwd:norm2(sub2(RSIDE.look,eye)),up:[0,1,0],fov:RSIDE.fov};}

/* ---------- Drone follow ---------- */
const FOL={yaw:null,yawV:0,off:null,pv:[0,0,0],t:0},FOL_H=15.2,FOL_B=12;
function followStep(t,dt,cut){
  const sp=t.speed,M=t.M;let dir=norm2([M[0],0,M[6]]);if(sp>3&&t.v[0]*t.v[0]+t.v[2]*t.v[2]>1)dir=norm2([t.v[0],0,t.v[2]]);
  const ty=Math.atan2(-dir[2],dir[0]);if(FOL.yaw===null||cut){FOL.yaw=ty;FOL.yawV=0;FOL.off=null;}
  let d=ty-FOL.yaw;while(d>PI)d-=TAU;while(d<-PI)d+=TAU;[FOL.yaw,FOL.yawV]=springTo(FOL.yaw,FOL.yawV,FOL.yaw+d,2.6,dt);
  FOL.t+=dt;const T=FOL.t,h=[Math.cos(FOL.yaw),0,-Math.sin(FOL.yaw)],right=[-h[2],0,h[0]];
  /* the drift: a metre and a bit each way over 9 s, with a quicker little wander on top; the bob a quarter of a metre */
  const drift=1.3*Math.sin(T*TAU/9)+.45*Math.sin(T*TAU/3.7+1),driftV=1.3*TAU/9*Math.cos(T*TAU/9)+.45*TAU/3.7*Math.cos(T*TAU/3.7+1);
  const back=FOL_B+clamp(sp*.08,0,4),off=[-h[0]*back+right[0]*drift,FOL_H+.25*Math.sin(T*1.3),-h[2]*back+right[2]*drift];
  if(!FOL.off){FOL.off=off.slice();FOL.pv=[0,0,0];}
  for(let k=0;k<3;k++){const q=springTo(FOL.off[k],FOL.pv[k],off[k],2.8,dt);FOL.off[k]=q[0];FOL.pv[k]=q[1];}
  const eye=add(t.p,FOL.off),gy=RANCH.W.heightAt(eye[0],eye[2])+6;if(eye[1]<gy)eye[1]=gy;
  const lead=clamp(sp*.1,0,3.5),at=[t.p[0]+dir[0]*lead,t.p[1]+.3,t.p[2]+dir[2]*lead],fwd=norm2(sub2(at,eye));
  const rt=V3.norm(V3.cross(fwd,[0,1,0])),bank=clamp(-driftV*.035-FOL.yawV*.06,-.1,.1),up=V3.norm([rt[0]*bank,1,rt[2]*bank]);
  return {eye,fwd,up,fov:.8};}

/* how close the picture's near edge can come, per camera (the cockpit's cabin is right round you) */
function sasNear(){
  if(APP.orbit)return .3;if(JUMP.on)return .2;const m=CAMS[APP.cam];
  if(m==='Hood')return .12;if(m==='Cockpit')return COCK.seat?.06:.12;if(CAM.rear)return .3;
  if(m==='Cinematic'&&CINE.ok)return CINE.near;if(m==='Low drone'&&LOWD.ok)return LOWD.near;
  if(m==='Wheel cam'||m==='Roadside')return .1;return .3;}
