  /* Studio 2's own surfaces (Salt Mini Plus models/src/hd: the Studio kit's SM ids, 70 to 108), as the Studio viewer
     draws them, in this shader's terms: shin from the viewer's roughness (rough = sqrt(2/(shin+2))), metal its
     metalness, clear its clear coat; the lamps light with the bay's Lights as the game's own lamps do. (The windows
     and clear lenses come in partly kept, the game's own see-through: 63_s2 s2Make) */
  else if(m>=70&&m<=108){
    float gr=vn3(vL*90.);
    if(m==70||m==108||m==97){alb=vec3(.02);spec=1.;shin=20000.;ssr=1.;f0k=1.6;
      if(m==108)emc=vec3(1.,.97,.9)*uLamps*1.6;else if(m==97)emc=vec3(.9)*uLamps*.08;}
    else if(m==71){emc=vec3(1.,.96,.88)*(.1+uLamps*3.);alb=vec3(.6);spec=.6;shin=200.;}
    else if(m==72){spec=.5;shin=137.;clear=1.;clearR=.05;}
    else if(m==73){alb*=.88+.24*gr;spec=.12;shin=3.2;}
    else if(m==74){alb*=.8+.4*vn3(vL*140.);spec=.02;shin=1.;}
    else if(m==75){alb*=.9+.2*gr;spec=.1;shin=1.6;}
    else if(m==76||m==99){alb*=.9+.2*vn3(vL*120.);spec=.05;shin=1.;dirty=true;}
    else if(m==77){spec=.06;shin=1.3;dirty=true;}
    else if(m==78){spec=.8;shin=76.;metal=1.;}
    else if(m==79){alb=vec3(.84,.85,.87);spec=1.;shin=550.;metal=1.;}
    else if(m==80){spec=.6;shin=12.;metal=.85;dirty=true;}
    else if(m==81){alb=vec3(.9);spec=1.;shin=1250.;metal=1.;}
    else if(m==82){emc=vec3(1.,.48,.06)*(.12+uLamps*.5);alb=vec3(.6,.22,.02);spec=1.;shin=3000.;ssr=.6;}
    else if(m==83){float on=max(uLamps*.5,uBrake);emc=vec3(1.,.05,.03)*(.2+on*2.4);alb=vec3(.45,.01,.006);spec=1.;shin=3000.;ssr=.6;}
    else if(m==84){alb*=.85+.3*gr;spec=.04;shin=.5;}
    else if(m==85){spec=.02;shin=0.;}
    else if(m==86){spec=.3;shin=20.;}
    else if(m==87){spec=.6;shin=17.5;metal=.8;}
    else if(m==88){spec=.7;shin=20.;metal=1.;}
    else if(m==89){spec=.05;shin=2.;}
    else if(m==90){alb=vec3(.9);spec=1.;shin=40000.;metal=1.;ssr=1.;}
    else if(m==91){alb=vec3(.01);spec=1.;shin=2000.;ssr=1.;}
    else if(m==92){spec=.4;shin=14.;clear=.5;clearR=.08;}
    else if(m==93){spec=.5;shin=4.6;metal=.7;dirty=true;}
    else if(m==94){alb*=.85+.3*vn3(vL*24.);spec=.05;shin=1.1;dirty=true;}
    else if(m==95){alb=uClad*(.9+.2*gr);spec=.07;shin=1.8;dirty=true;}
    else if(m==96){emc=vec3(1.,.97,.9)*(uLamps*5.+.06);alb=vec3(.85,.86,.88);spec=1.;shin=1250.;metal=.5;}
    else if(m==98){alb=vec3(.32,.004,.002);spec=.6;shin=137.;clear=1.;clearR=.03;}
    else if(m==100){alb*=.85+.3*vn3(vL*22.);spec=.04;shin=.7;dirty=true;}
    else if(m==101){alb*=.88+.24*gr;spec=.07;shin=2.1;dirty=true;}
    else if(m==102){alb*=.85+.3*vn3(vL*20.);spec=.02;shin=.2;}
    else if(m==103){spec=.5;shin=9.3;clear=.6;clearR=.08;}
    else if(m==104){spec=.6;shin=9.3;metal=.6;}
    else if(m==105){spec=.1;shin=3.6;}
    else if(m==106){spec=.4;shin=14.;clear=.8;clearR=.06;}
    else{spec=.1;shin=4.6;}
  }
