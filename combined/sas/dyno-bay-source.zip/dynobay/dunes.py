"""(Salt & Sand) the changes on top of the Dyno Bay's, run by build.py --dunes with its rep and G: the world
becomes salt flats and white sand dunes with a road through the middle, the car is driven as its Studio 2, and the
bay is the menu with a Drive button. Every change replaces a piece of the game's text that must be there once."""

# ---- the world's generator (it runs in the world's worker as text, so the changes are made in its own text) ----
rep("function WORLDGEN(SEED){\n'use strict';\nSEED=SEED|0;\n","function WORLDGEN(SEED){\n'use strict';\nSEED=SEED|0;\n/* (Salt & Sand: the world is salt and sand, sas_world.js) */\nconst DUNES=true;\n")
rep("const SURF=['grass','dirt','strip','trail','rock','mud','concrete','water','gravel','asphalt','ruts'];\nconst SF={};",
    "const SURF=['grass','dirt','strip','trail','rock','mud','concrete','water','gravel','asphalt','ruts','sand'];\nconst SF={};")
rep("function core(x,z,ctx,o){\n  const td=townD(x,z);",rd('sas_world.js')+"function core(x,z,ctx,o){\n  if(DUNES)return duneCore(x,z,o);\n  const td=townD(x,z);")
rep("function baseAt(x,z){\n  const k=hillK(x,z)","function baseAt(x,z){\n  if(DUNES)return rimAt(x,z);\n  const k=hillK(x,z)")
rep("function boxCtx(x0,z0,x1,z1){\n  const P=plansIn","function boxCtx(x0,z0,x1,z1){\n  if(DUNES)return {plans:[],pads:[],spurs:[],ns:[],ew:[]};\n  const P=plansIn")
rep("const clsNSz=(i,z)=>{if(i<-1||i>1)return 0;","const clsNSz=(i,z)=>{if(DUNES||i<-1||i>1)return 0;")
rep("const clsEWx=(j,x)=>{if(j<-1||j>1)return 0;","const clsEWx=(j,x)=>{if(DUNES)return j===0&&Math.abs(x)<HALF-800?3:0;if(j<-1||j>1)return 0;")
# (the chunks' statics: the road and its shoulders only)
rep("  /* --- the town --- */\n  if(x1>-EDGE-40&&x0<EDGE+40&&z1>-EDGE-40&&z0<EDGE+40)townStatic(",
    "  if(DUNES){let bb=[0,1e9,0,CH,-1e9,CH];const P=RB.P;for(let i=0;i<P.length;i+=3){if(P[i]<bb[0])bb[0]=P[i];if(P[i]>bb[3])bb[3]=P[i];if(P[i+1]<bb[1])bb[1]=P[i+1];if(P[i+1]>bb[4])bb[4]=P[i+1];if(P[i+2]<bb[2])bb[2]=P[i+2];if(P[i+2]>bb[5])bb[5]=P[i+2];}\n"
    "    if(bb[1]>bb[4]){bb[1]=0;bb[4]=1;}return {cx,cz,roads:RB.n?RB.out():null,props:null,trees:new Float32Array(0),cols,lights,labels,bb:[x0+bb[0],bb[1],z0+bb[2],x0+bb[3],bb[4],z0+bb[5]]};}\n"
    "  /* --- the town --- */\n  if(x1>-EDGE-40&&x0<EDGE+40&&z1>-EDGE-40&&z0<EDGE+40)townStatic(")
# (the sand's weight rides in the colour's first channel, negative, as the salt's does in its third)
rep("Wt[k*4]=o.grass;Wt[k*4+1]=o.rock;Wt[k*4+2]=o.salt>.02?-o.salt:o.mud;","Wt[k*4]=o.sand>.02?-o.sand:o.grass;Wt[k*4+1]=o.rock;Wt[k*4+2]=o.salt>.02?-o.salt:o.mud;")
rep("rs=sst(.6,1.05,slope)*(Wt[k*4+2]<0?0:1);","rs=sst(.6,1.05,slope)*(Wt[k*4+2]<0||Wt[k*4]<0?0:1);")
rep("wd=sst(.56-.2*o.k,.66-.2*o.k,wn)*(o.salt>0?0:1);\n      Wt[k*4]=Math.max(o.grass,wd);","wd=sst(.56-.2*o.k,.66-.2*o.k,wn)*(o.salt>0||o.sand>0?0:1);\n      Wt[k*4]=o.sand>.02?-o.sand:Math.max(o.grass,wd);")
rep("for(const q of TW.lots){if(q.h<30)continue;","for(const q of DUNES?[]:TW.lots){if(q.h<30)continue;")
rep("function townLights(){\n  if(TOWN_LIGHTS)return TOWN_LIGHTS;","function townLights(){\n  if(DUNES)return TOWN_LIGHTS=[];\n  if(TOWN_LIGHTS)return TOWN_LIGHTS;")
rep("[46,46,52],[84,58,32]];","[46,46,52],[84,58,32],[236,232,222]];")

# ---- the ground's shader: the white sand ----
rep("      float sw=smoothstep(.05,.75,-vC.b+(n2-.5)*.18);\n","      float sw=smoothstep(.05,.75,-vC.b+(n2-.5)*.18);\n      /* (Salt & Sand: the sand's weight, the colour's first channel negative) */\n      float dw=vC.r<0.?smoothstep(.02,.6,-vC.r):0.;\n")
rep("      bool dirt=!(sw>=1.||sw<=.004&&max(gw,rw)>=1.);\n#else\n      bool dirt=!(sw<=.004&&gw>=1.);\n#endif",
    "      bool dirt=!(sw>=1.||sw<=.004&&max(gw,rw)>=1.)&&dw<1.;\n#else\n      bool dirt=!(sw<=.004&&gw>=1.)&&dw<1.;\n#endif")
rep("      if(gw>.004){vec3 gc=grassCol(wp);vec2 g0=gG;gG=vec2(0.);grassDetail(wp,gc);",
    "      /* (Salt & Sand) the white gypsum: cream white in big soft patches, the wind's ripples across it (crests running\n"
    "         north and south, a few centimetres apart, faded out once they're smaller than a pixel) */\n"
    "      if(dw>.004){vec3 sd=vec3(.80,.77,.70)*(.9+.12*vn(wp*.012)+.05*vn(wp*.37));\n"
    "        float ph=dot(wp,vec2(.93,.37))*26.+vn(wp*.35)*5.;gG=mix(gG,vec2(.93,.37)*cos(ph)*.32*near(.09),dw);\n"
    "        alb=mix(alb,sd,dw);gw*=1.-dw;rw*=1.-dw;}\n"
    "      if(gw>.004){vec3 gc=grassCol(wp);vec2 g0=gG;gG=vec2(0.);grassDetail(wp,gc);")

# ---- the game round it: where you start, the dust, the sand's drag, the time of day, nothing else in the world ----
rep("const HOME=[58,95,-PI/2];","const HOME=[0,1.9,0];")
rep("const FX_COL={dirt:[.36,.22,.12],trail:[.4,.27,.15],strip:[.42,.3,.2],","const FX_COL={sand:[.8,.77,.7],dirt:[.36,.22,.12],trail:[.4,.27,.15],strip:[.6,.57,.52],")
rep("SURF_RR.salt=.016;SURF_RR.sand=.07;","SURF_RR.salt=.016;SURF_RR.sand=.035;",2)
rep("lights:true,tod:'night',steer:'slide'","lights:true,tod:'day',steer:'slide'")
rep("function placeName(x,z){return WG.placeAt(x,z);}","function placeName(x,z){if(DYB.dunes)return Math.abs(z)<6?'Highway 40':z<0?'The salt flats':'The white sands';return WG.placeAt(x,z);}")
rep("function chalDraw(cam){\n","function chalDraw(cam){\n  if(DYB.dunes)return 0;\n")
rep("else{lapStep(dt,t);runStep(dt,t);parkStep(dt,t);chalStep(dt,t,ev);}","else if(!DYB.dunes){lapStep(dt,t);runStep(dt,t);parkStep(dt,t);chalStep(dt,t,ev);}")
rep("function jobIntro(){","function jobIntro(){if(DYB.dunes)return;")
# (the far cascades of the sun's shadow take the car's coarse copy: the near one, where its shadow is seen, the Studio 2)
rep("if(kind!=='hl')one(GAME.car,k>=1&&budgetOn()&&BUDGET.carLod>.5);","if(kind!=='hl')one(GAME.car,k>=1);")
# ---- the car you drive: Studio 2 ----
rep("/* =====================================================================================\n   THE BOOT: the dots",rd('sas.js')+rd('sas_cams.js')+"\n/* =====================================================================================\n   THE BOOT: the dots")
rep("function drawWorldCar(t,v,dirt,far,depth){\n","function drawWorldCar(t,v,dirt,far,depth){\n  /* (Salt & Sand: your car is its Studio 2; while it's being made, nothing) */\n  if(t===GAME.car&&!far){const S2=s2For(t.bi),k=s2Key(t.bi);if(S2)return drawS2World(t,v,dirt,depth,S2);if(k&&!DYB.err[k])return 0;}\n")
# (the desert's air: clearer than the county's, the sun harder against the sky's light, the exposure set for white sand)
rep("E.grade=[T.grade[0]*LOOK.sat,T.grade[1]*LOOK.con];E.expoBias=1;\n  return E;\n}","E.grade=[T.grade[0]*LOOK.sat,T.grade[1]*LOOK.con];E.expoBias=1;\n  if(DYB.dunes){const A=DYB.air;E.fogDen*=A.fog;E.fogAmb=E.fogAmb.map(v=>v*A.fog);E.ambUp=E.ambUp.map(v=>v*A.amb);E.key*=A.key;}\n  return E;\n}")
# ---- the cameras: Chase, Far, Hood and Salt Flats' Cinematic (sas.js cineStep), heard from where it stands ----
rep("const CAMS=['Chase','Far','Hood'];","const CAMS=['Chase','Far','Hood','Cinematic','Drone lead','Drone tail','Drone left','Drone right','Drone orbit','Low drone','Drone follow','Cockpit','Wheel cam','Tracking car','Roadside'];")
rep("if(s.cam>=0&&s.cam<3)APP.cam=s.cam|0;","if(s.cam>=0&&s.cam<15)APP.cam=s.cam|0;")
rep("  if(mode==='Hood'){\n    /* on the hood, just behind the front axle */","  /* (Salt & Sand: the Director and the jump cam first; then the cameras of its own) */\n  {const J=camAuto(t,dt);if(J)return J;}\n  if(mode==='Cinematic'){CAM.yaw=null;CAM.off=null;CAM.fq=null;return cineStep(t,dt,cut);}\n  if(mode==='Cockpit'){CAM.yaw=null;CAM.off=null;CAM.fq=null;return cockStep(t,dt,cut);}\n  if(mode==='Wheel cam'){CAM.yaw=null;CAM.off=null;CAM.fq=null;return wheelStep(t,dt,cut);}\n  if(mode==='Tracking car'){CAM.yaw=null;CAM.off=null;CAM.fq=null;return trackStep(t,dt,cut);}\n  if(mode==='Roadside'){CAM.yaw=null;CAM.off=null;CAM.fq=null;return roadStep(t,dt,cut);}\n  if(mode==='Drone follow'){CAM.yaw=null;CAM.off=null;CAM.fq=null;return followStep(t,dt,cut);}\n  if(mode==='Low drone'){CAM.yaw=null;CAM.off=null;CAM.fq=null;return lowStep(t,dt,cut);}\n  if(mode.startsWith('Drone ')){CAM.yaw=null;CAM.off=null;CAM.fq=null;return droneStep(t,dt,cut,mode.slice(6));}\n  if(mode==='Hood'){\n    /* on the hood, just behind the front axle */")
rep("const mode0Near=()=>CAMS[APP.cam]==='Hood'&&!APP.orbit?.12:.3;","const mode0Near=()=>sasNear();")
rep("  if(mode==='Hood'&&!APP.orbit)geo={dist:3.2,pan:0,rear:.3};\n","  if(mode==='Hood'&&!APP.orbit)geo={dist:3.2,pan:0,rear:.3};\n  let lis=0,dop=1;if(mode==='Cinematic'&&!APP.orbit&&!CAM.rear&&CINE.ok&&!paused){const q=cineSound(t,right);geo=q.geo;lis=2;dop=q.dop;}\n  if(mode==='Low drone'&&!APP.orbit&&!CAM.rear&&LOWD.ok&&!paused){const q=cineSound(t,right,LOWD.p,LOWD.vel);geo=q.geo;lis=2;dop=q.dop;}\n  if(!APP.orbit&&!CAM.rear&&!paused){if(JUMP.on){const q=cineSound(t,right,JUMP.p);geo=q.geo;lis=2;dop=q.dop;}else if(mode==='Roadside'&&RSIDE.ok){const q=cineSound(t,right,RSIDE.p);geo=q.geo;lis=2;dop=q.dop;}else if(mode==='Cockpit'){geo={dist:1.4,pan:0,rear:.35};lis=1;}}\n")
rep("  const ep=t.pt.soundParams(0,t.speed,geo);","  const ep=t.pt.soundParams(lis,t.speed,geo);if(dop!==1)ep.rpm*=dop;")
# (the Drive tab's camera row: one Drone button for the four drones, pressed again for the next of them; Orbit apart)
rep("  segButtons($('mCam'),CAMS.map((n,i)=>[i,n]),i=>{APP.cam=+i;CAM.cut=true;saveGame();});",
    "  camRowBuild();camSetBuild();")
rep("  for(const el of $('mCam').children)el.setAttribute('aria-pressed',String(+el.dataset.v===APP.cam));",
    "  camSetSync();")
# (on a phone the bar's one chip: Bay while you drive, Drive in the menu)
s_css_old="#mTabs [data-t=chals],#mTabs [data-t=races],#mTabs [data-t=cool],#mTabs [data-t=runs],#tabDev,#mLeave,#menuBtn,"
assert G.count(s_css_old)==1
G=G.replace(s_css_old,"#mTabs [data-t=chals],#mTabs [data-t=races],#mTabs [data-t=cool],#mTabs [data-t=runs],#tabDev,#mLeave,")
# ---- the menu: Esc from the road opens the bay; the bay's Drive takes you back out ----
rep("showTab(MENU.tab);syncMenu();setTimeout(()=>$('mGo').focus({preventScroll:true}),0);\n}",
    "showTab(MENU.tab);syncMenu();setTimeout(()=>$('mGo').focus({preventScroll:true}),0);\n  if(!first&&MENU.tab==='garage')showFull(true);\n}")
rep('<span id="shEngLbl">Start engine</span></button></div>','<span id="shEngLbl">Start engine</span></button><button class="btn go sm" id="sasDrive" type="button">Drive ▶</button></div>')
rep("Your car on the dyno as its Studio 2, the whole screen:","Your car on the dyno as its Studio 2 (Drive ▶ takes it out onto the salt and the sand), the whole screen:")
rep("L.hidden=true;openMenu(true);dybStart();","L.hidden=true;openMenu(true);dybStart();sasBoot();")
G=G.replace("window.__dyb={DYB,","window.__dyb={CAMS,get CAMSET(){return CAMSET;},get JUMP(){return JUMP;},get RSIDE(){return RSIDE;},get COCK(){return COCK;},get WHEEL(){return WHEEL;},get TRK(){return TRK;},get FOL(){return FOL;},get DIR(){return DIR;},camSetBuild,camRowBuild,camPick,camNext,get CINE(){return CINE;},get LOWD(){return LOWD;},get DRONE(){return DRONE;},applyTod,drawS2World,step,setTestInput,placeCar,GLC,get WORLD(){return WORLD;},get CAM(){return CAM;},get RANCH(){return RANCH;},closeMenu,openMenu,get WG(){return WG;},get INPUT(){return INPUT;},DYB,",1)
# ---- the cameras chosen (sas_cams.js): the camera button goes through the ones that are on ----
rep("    if(inp.cam){APP.cam=(APP.cam+1)%CAMS.length;CAM.cut=true;saveGame();say(CAMS[APP.cam]+' camera',1.2);}","    if(inp.cam)camNext();")
# (the car's own glass all but clear from the cockpit: its see-through pixels kept the less, uSeeX)
rep("uniform float uMudOff;uniform float uMudLocal;","uniform float uMudOff;uniform float uMudLocal;uniform float uSeeX;")
rep("if(em<0.){if(ign(gl_FragCoord.xy,uFrame)>-em)discard;em=0.;}","if(em<0.){if(ign(gl_FragCoord.xy,uFrame)>-em*(1.-uSeeX))discard;em=0.;}")
# (Settings: the Cameras drop-down, first)
rep('<div class="tab" data-tab="settings" hidden>\n','<div class="tab" data-tab="settings" hidden>\n      <section id="sCams"><details><summary>Cameras</summary>\n        <p class="hint">The camera button (<kbd>C</kbd>, or CAM on a phone) only goes through the cameras that are on. The <b>Director</b> switches between them by itself, holding each for its time. <b>Jump cam</b> cuts to a camera off to the side whenever the car takes off, and back once it lands.</p>\n        <div class="row2" style="margin-top:10px"><div><h2 class="sub">Director</h2><div class="seg" id="sDir" role="group" aria-label="Director"></div></div><div><h2 class="sub">Jump cam</h2><div class="seg" id="sJump" role="group" aria-label="Jump cam"></div></div></div>\n        <h2 class="sub" style="margin-top:12px">Cameras · Director time</h2><div class="camrows" id="sCamList"></div></details></section>\n')
assert G.count("  #dl .panel canvas{height:190px}#dl .bchart canvas{height:200px}}\n</style>")==1
G=G.replace("  #dl .panel canvas{height:190px}#dl .bchart canvas{height:200px}}\n</style>","  #dl .panel canvas{height:190px}#dl .bchart canvas{height:200px}}\n"+"""#sCams summary{cursor:pointer;list-style:none;font:600 13px/1 var(--f);letter-spacing:.14em;text-transform:uppercase;color:var(--ink);padding:8px 0}
#sCams summary::-webkit-details-marker{display:none}#sCams summary::after{content:' \\25BE';color:var(--ink-2)}#sCams details[open] summary::after{content:' \\25B4'}
.camrows{display:grid;gap:6px;margin-top:8px;max-width:520px}
.camrow{display:flex;align-items:center;gap:10px;padding:5px 6px 5px 6px;border:1px solid var(--edge);border-radius:14px;background:var(--panel)}
.camrow .nm{flex:1;font:600 11.5px/1.2 var(--f);letter-spacing:.08em;text-transform:uppercase;color:var(--ink-2)}.camrow.on .nm{color:var(--ink)}
.camrow button{border:1px solid var(--edge);background:none;color:var(--ink-2);border-radius:999px;height:30px;min-width:32px;padding:0 10px;font:600 11px/1 var(--f);letter-spacing:.08em;cursor:pointer}
.camrow .sw{min-width:54px}.camrow .sw[aria-pressed=true]{background:var(--raised);color:var(--ink);box-shadow:0 0 0 1px var(--edge-2) inset}
.camrow .tm{display:flex;align-items:center;gap:4px}.camrow .tm b{min-width:42px;text-align:center;font:600 12px/1 var(--f);color:var(--ink)}.camrow:not(.on) .tm{opacity:.35}
#mCam{flex-wrap:wrap;border-radius:18px}
</style>""",1)
print('Salt & Sand: the world, the car and the menu changed')
