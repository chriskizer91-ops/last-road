/* the cameras chosen (sas_cams.js), tried in a test browser on the SUV:
   A. on the road at speed: Cockpit, Wheel cam, Tracking car, Roadside and Drone follow, a picture of each and where
      each sits from the car;  B. the Director on three cameras, held 4, 4 and 6 s: when it switched and to what;
   C. Jump cam over the dunes: when it cut in and back, a picture mid-jump;  D. the cockpit of the other cars.
   node tools/cams.js [salt-and-sand.html] [parts, e.g. ABCD]   (pictures cams_*.png here) */
const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const parts=process.argv[3]||'ABCD';
(async()=>{const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 const p=await b.newPage({viewport:{width:800,height:450}});const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error')errs.push(m.text().slice(0,300));});
 await p.goto('file://'+require('path').resolve(process.argv[2]||'salt-and-sand.html')+'?quality=mobile');
 await p.waitForFunction(()=>window.__dyb&&document.getElementById('loading').hidden&&window.__dyb.DYB.S2.size>0,null,{timeout:900000,polling:500});
 const shot=n=>p.screenshot({path:'cams_'+n+'.png',timeout:900000});
 /* n frames of the game, a picture-frame drawn every `every`; where the camera is against the car */
 const run=(n,inp,every=10)=>p.evaluate(async([n,inp,every])=>{const Y=window.__dyb;Y.setTestInput(inp);
   for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.step(1/60);if(i%every==every-1){Y.render(every/60);await new Promise(r=>setTimeout(r,2));}}
   const t=Y.GAME.car,e=Y.CAM.last.eye,M=t.M,f=[M[0],M[6]],fl=Math.hypot(...f),rel=[e[0]-t.p[0],e[1]-t.p[1],e[2]-t.p[2]];
   const fwd=(rel[0]*f[0]+rel[2]*f[1])/fl,side=(rel[0]*-f[1]+rel[2]*f[0])/fl;
   return {cam:Y.CAMS[Y.APP.cam],jump:Y.JUMP.on,mph:Math.round(t.speed*2.237),ahead:+fwd.toFixed(2),side:+side.toFixed(2),aboveCar:+rel[1].toFixed(2),
     aboveGround:+(e[1]-Y.RANCH.W.heightAt(e[0],e[2])).toFixed(2),dist:+Math.hypot(...rel).toFixed(2),fovDeg:Math.round(Y.CAM.last.fov*180/Math.PI),
     roundDeg:Math.round(Math.atan2(side,fwd)*180/Math.PI)};},[n,inp,every]);
 const drive=async(place,cam)=>p.evaluate(([place,cam])=>{const Y=window.__dyb;Y.GAME.hold=true;if(Y.GAME.state!=='drive')document.getElementById('sasDrive').click();
   Y.placeCar(...place);Y.APP.cam=0;Y.CAM.cut=true;Y.setTestInput({steer:0,thr:1,brk:0,hb:0,nos:false});
   for(let i=0;i<300;i++){Y.APP.t+=1/60;Y.step(1/60);if(i%60==59)Y.render(1);}Y.APP.cam=cam;Y.CAM.cut=true;},[place,cam]);
 const cruise={steer:0,thr:.55,brk:0,hb:0,nos:false};
 const setCams=o=>p.evaluate(o=>{const Y=window.__dyb;Object.assign(Y.CAMSET,o);Y.camRowBuild();Y.camSetBuild();},o);
 if(parts.includes('A')){
   await setCams({dir:false,jump:false});
   const info=await p.evaluate(()=>{const Y=window.__dyb,S=Y.s2For(Y.APP.bi);return {car:S&&S.key,eye:S&&S.info.eye,roofOverEye:S&&S.info.roof};});
   console.log('A eye',JSON.stringify(info));
   for(const [cam,name] of (process.env.CAMS_A1||'11:cockpit,12:wheel,10:follow').split(',').map(q=>q.split(':')).map(([a,b])=>[+a,b])){await drive([0,1.9,0],cam);const r=await run(150,cruise);await shot('A_'+name);console.log('A',name,JSON.stringify(r));}
   if(process.env.CAMS_A1)return console.log(errs.slice(0,6).join('\n')||'no errors'),b.close();
   /* the tracking car: where its arm is, once a second for 26 s */
   await drive([0,1.9,0],13);let ang=[],pic=0;
   for(let s=0;s<26;s++){const r=await run(60,cruise,15);ang.push(Math.abs(r.roundDeg));if(s===4||s===15){await shot('A_tracking'+(++pic));console.log('A tracking',JSON.stringify(r));}}
   console.log('A tracking arm from the nose, degrees, each second:',ang.join(' '));
   /* roadside: each camera's closest pass */
   await drive([0,1.9,0],14);let best=null,spots=new Set(),took=0;
   for(let s=0;s<60;s++){const r=await run(10,cruise,10),n=await p.evaluate(()=>window.__dyb.RSIDE.n);spots.add(n);
     if(n===2&&(!best||r.dist<best.dist))best=r;if(n===2&&!took&&r.ahead>-6&&r.ahead<6){took=1;await shot('A_roadside');console.log('A roadside at the pass',JSON.stringify(r));}}
   console.log('A roadside closest',JSON.stringify(best),'cameras in 10 s:',spots.size);
   /* drone follow's drift over 18 s */
   await drive([0,1.9,0],10);const sd=[],hh=[],bk=[];for(let s=0;s<36;s++){const r=await run(30,cruise,10);sd.push(r.side);hh.push(r.aboveCar);bk.push(-r.ahead);}
   console.log('A follow over 18 s',JSON.stringify({sideways:[Math.min(...sd),Math.max(...sd)],aboveCar:[Math.min(...hh),Math.max(...hh)],behind:[Math.min(...bk),Math.max(...bk)]}));}
 if(parts.includes('B')){
   await setCams({on:[0,10,13],t:{...(await p.evaluate(()=>window.__dyb.CAMSET.t)),0:4,10:4,13:6},dir:true,jump:false});
   await drive([0,1.9,0],0);await p.evaluate(()=>{window.__dyb.DIR.t=0;});let last=null,log=[];
   for(let k=0;k<=180;k++){const r=await run(10,cruise,10);if(r.cam!==last){log.push((k/6).toFixed(1)+'s '+r.cam);last=r.cam;}}
   console.log('B director (Chase 4 s, Drone follow 4 s, Tracking car 6 s):',log.join(' | '));
   await setCams({dir:false});}
 if(parts.includes('C')){
   await setCams({jump:true,dir:false});await drive([420,170,0],0);let last=false,log=[],took=0;
   for(let k=0;k<16*6;k++){const r=await run(10,{steer:0,thr:.8,brk:0,hb:0,nos:false},10);
     if(r.jump!==last){log.push((k/6).toFixed(1)+'s '+(r.jump?'jump cam in':'back to '+r.cam));last=r.jump;}
     if(r.jump&&!took){const q=await p.evaluate(()=>window.__dyb.JUMP.t);if(q>.3){took=1;await shot('C_jump');console.log('C mid-jump',JSON.stringify(r));}}}
   console.log('C jump cam:',log.join(' | ')||'no jump');}
 if(parts.includes('D')){
   const CAR=Object.fromEntries((process.env.CAMS_D||'race:suv,coupe:coupe,hatch:hatch,wedge:wedge').split(',').map(q=>q.split(':')));
   for(const k of Object.keys(CAR)){
     await p.evaluate(([car,k])=>{const Y=window.__dyb;Y.openMenu();Y.showFull(true);if(Y.APP.car!==car)Y.pickCar(car);Y.RIGS[car]=Y.presetRig(k);Y.spawnRig();Y.s2For(Y.APP.bi);},[CAR[k],k]);
     await p.waitForFunction(k=>window.__dyb.DYB.S2.has(k),k,{timeout:900000,polling:500});
     await drive([0,1.9,0],11);const r=await run(120,cruise);
     const info=await p.evaluate(()=>{const Y=window.__dyb,S=Y.s2For(Y.GAME.car.bi);return {car:S&&S.key,eye:S&&S.info.eye,roofOverEye:S&&S.info.roof};});
     await shot('D_cockpit_'+k);console.log('D',JSON.stringify(info),JSON.stringify(r));}}
 console.log(errs.slice(0,6).join('\n')||'no errors');await b.close();})();
