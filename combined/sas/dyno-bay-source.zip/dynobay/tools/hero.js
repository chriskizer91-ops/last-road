const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const shots=JSON.parse(process.argv[2]),Q=process.argv[3]||'high',W=+(process.argv[4]||1280),H=+(process.argv[5]||720);
(async()=>{const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 const p=await b.newPage({viewport:{width:W,height:H}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.goto('file:///home/claude/dynobay/salt-and-sand.html?quality='+Q);
 await p.waitForFunction(()=>window.__dyb&&document.getElementById('loading').hidden&&window.__dyb.DYB.S2.size>0,null,{timeout:900000,polling:500});
 await p.evaluate(()=>{const Y=window.__dyb;Y.GAME.hold=true;document.getElementById('sasDrive').click();});
 for(const [name,code,pre,n] of shots){
  const r=await p.evaluate(async([code,pre,n])=>{const Y=window.__dyb;await (new Function('Y','return (async()=>{'+code+'})()'))(Y);
    for(let i=0;i<pre;i++){Y.APP.t+=1/60;Y.step(1/60);if(i%15==14){Y.render(1/60);await new Promise(r=>setTimeout(r,20));}}
    for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.step(1/60);Y.render(1/60);await new Promise(r=>setTimeout(r,20));}
    const t=Y.GAME.car,G=window.__game;return {mph:+(t.speed*2.237).toFixed(0),y:+t.p[1].toFixed(1),tris:Y.APP.tris,render:[G.R.iw,G.R.ih],scale:G.R.scale};},[code,pre,n]);
  await p.screenshot({path:'/tmp/hero_'+name+'.png',timeout:1500000});console.log(name,JSON.stringify(r));}
 console.log(errs.slice(0,6).join('\n')||'no errors');await b.close();})();
