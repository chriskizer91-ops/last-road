/* The Dyno Bay's checks, with pictures: boot, the Studio 2 car on the dyno, the views (Under among them), the
   engine started and the car driven through the gears on the dyno (gear, revs, squat, roll, the engine's rock),
   looking underneath while it revs, every Studio 2 build made in turn. The loop is held (GAME.hold) and the page
   stepped here: the sim at 1/60 s a step, then a few frames drawn so the picture settles.
   usage: node tools/check.js <page.html> <out-dir> [cars: all | key,key]   env: W, H, Q */
const {chromium}=require('/opt/npm-tools/node_modules/playwright');const fs=require('fs'),path=require('path');
const page=path.resolve(process.argv[2]),out=process.argv[3]||'/tmp/dyb',which=process.argv[4]||'';fs.mkdirSync(out,{recursive:true});
(async()=>{
  const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--autoplay-policy=no-user-gesture-required']});
  const p=await b.newPage({viewport:{width:+(process.env.W||960),height:+(process.env.H||540)},deviceScaleFactor:1});
  const errs=[];p.on('pageerror',e=>errs.push('pageerror: '+e.message));p.on('console',m=>{if(m.type()==='error'||m.type()==='warning')errs.push(m.type()+': '+m.text().slice(0,400));});
  const t0=Date.now(),T=()=>((Date.now()-t0)/1000).toFixed(0)+'s';
  await p.goto('file://'+page+'?quality='+(process.env.Q||'mobile'));
  await p.waitForFunction(()=>window.__dyb&&document.getElementById('loading').hidden,null,{timeout:600000,polling:500});
  console.log('booted',T());
  await p.evaluate(()=>{const Y=window.__dyb;Y.GAME.hold=true;
    window.TT={
      /* the sim for sec seconds, the pad at thr (and the brake) */
      run(sec,thr=0,brk=false){const S=Y.SHOW;S.padOn=thr>0;S.pad=thr;S.brkBtn=brk;const n=Math.round(sec*60);for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.showSound(1/60);Y.showBody(1/60);}
        const sim=S.sim;return sim?{st:sim.st,gear:sim.gear,rpm:Math.round(sim.rpm),mph:+(sim.v*2.237).toFixed(1),whp:Math.round(S.whp),pitch:+S.pitch.toFixed(4),roll:+S.roll.toFixed(4),surge:+S.surge.toFixed(4),wheelA:+S.wheelA.toFixed(1)}:null;},
      draw(n=8){for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.render(1/60);}return Y.GAME.voice&&0;},
      view(v){Y.showSetView(v);Y.SHOW.cam=null;Y.SHOW.yaw=0;},
      cam(o){Y.SHOW.camT=Object.assign({th:-30,ph:10,d:7,ty:.8},o);Y.SHOW.view=null;Y.SHOW.cam=null;},
      ready(){return [...Y.DYB.S2.keys()];},
      info(){const k=Y.s2Key(Y.APP.bi),S=Y.DYB.S2.get(k);return S?{k,tris:S.tris,draws:S.draws,ms:S.ms}:{k,building:!!Y.DYB.busy,err:Y.DYB.err[k]};}};});
  const ONLY=(process.env.ONLY||'').split(',').filter(Boolean),FR=+(process.env.FR||0);
  const shot=async(name,code,n=8)=>{if(ONLY.length&&!ONLY.includes(name)){return null;}if(FR)n=FR;const r=await p.evaluate(async([code,n])=>{const Y=window.__dyb;const v=await (new Function('Y','TT','return (async()=>{'+code+'})()'))(Y,TT);TT.draw(n);return v;},[code,n]);
    await p.screenshot({path:path.join(out,name+'.png'),timeout:600000});console.log(name,T(),JSON.stringify(r));return r;};
  const waitS2=async()=>{await p.waitForFunction(()=>{const Y=window.__dyb,k=Y.s2Key(Y.APP.bi);Y.s2For(Y.APP.bi);return !k||Y.DYB.S2.has(k)||Y.DYB.err[k];},null,{timeout:600000,polling:300});};
  await waitS2();
  await shot('front34',"TT.view('front34');return TT.info();",10);
  await shot('under',"TT.view('under');return TT.info();",10);
  /* the engine started, the car pulled through the gears on the dyno, watched from underneath */
  await shot('rev_under',"await Y.showEngine(true);const a=TT.run(2.5,0);const b=TT.run(2.2,1);TT.view('under');return {idle:a,pull:b,eng:Y.SHOW.eng,audio:!!Y.ENG.audio};",6);
  await shot('rev_side',"const c=TT.run(.6,1);TT.view('side');return c;",6);
  await shot('rev_bay',"const c=TT.run(.4,1);TT.view('bay');return c;",6);
  await shot('close_wheel',"const c=TT.run(.3,1);TT.cam({th:-25,ph:4,d:1.6,ty:.5,ox:1.4,oy:-.2,oz:.9});return c;",6);
  await shot('lift_off',"const c=TT.run(1.2,0);TT.view('rear34');return c;",6);
  await shot('garage',"TT.view('under');Y.showFull(false);return 0;",8);
  await shot('lab',"Y.showFull(true);Y.SHOW.tab='engine';window.__game.syncShow();TT.view('front34');const r=TT.run(1.5,1);return r;",8);
  await shot('pull',"Y.showPullStart();const g=[];for(let k=0;k<14;k++){const q=TT.run(1,0);g.push(q&&q.gear+':'+q.rpm);}return {g,peak:Y.SHOW.peak,ph:Y.PULL.ph};",8);
  const all=['stock','sleeper','crawler','race','coupe','coupeGT','hatch','hatchB','wedge','wedgeNR'];
  const want=which==='all'?all:which?which.split(','):[];
  const CAR={stock:'suv',sleeper:'suv',crawler:'suv',race:'suv',coupe:'coupe',coupeGT:'coupe',hatch:'hatch',hatchB:'hatch',wedge:'wedge',wedgeNR:'wedge'};
  for(const k of want){
    await p.evaluate(([car,k])=>{const Y=window.__dyb;if(Y.APP.car!==car)Y.pickCar(car);Y.RIGS[car]=Y.presetRig(k);Y.spawnRig();Y.s2For(Y.APP.bi);},[CAR[k],k]);
    await waitS2();
    await shot('car_'+k,"Y.SHOW.hood=true;Y.SHOW.hoodA=1;TT.view('front34');return TT.info();",8);
    await shot('car_'+k+'_under',"TT.view('under');return TT.info();",6);
  }
  console.log(errs.length?'page errors:\n  '+[...new Set(errs)].slice(0,14).join('\n  '):'no page errors');await b.close();
})();
