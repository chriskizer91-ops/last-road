/* Pictures and numbers from the Dyno Bay page: boot it, wait for the Studio 2 car, run each job's code in the page
   (G = window.__game, Y = window.__dyb), let it draw for a moment, shoot.
   usage: node tools/shot.js <page.html> <out-dir> 'name=code' ...   env: W, H, WAIT (ms after each job), Q (quality) */
const {chromium}=require('/opt/npm-tools/node_modules/playwright');const fs=require('fs'),path=require('path');
const page=path.resolve(process.argv[2]),out=process.argv[3]||'/tmp/dyb',jobs=process.argv.slice(4);fs.mkdirSync(out,{recursive:true});
(async()=>{
  const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--autoplay-policy=no-user-gesture-required']});
  const p=await b.newPage({viewport:{width:+(process.env.W||1280),height:+(process.env.H||720)},deviceScaleFactor:1});
  const errs=[];p.on('pageerror',e=>errs.push('pageerror: '+e.message));p.on('console',m=>{if(m.type()==='error'||m.type()==='warning')errs.push(m.type()+': '+m.text().slice(0,400));});
  const t0=Date.now();await p.goto('file://'+page+(process.env.Q?'?quality='+process.env.Q:''));
  await p.waitForFunction(()=>window.__dyb&&document.getElementById('loading').hidden,null,{timeout:600000,polling:500});
  console.log('booted',((Date.now()-t0)/1000).toFixed(0)+'s');
  await p.waitForFunction(()=>{const Y=window.__dyb;return Y.DYB.S2.size>0||Object.keys(Y.DYB.err).length>0;},null,{timeout:600000,polling:500});
  console.log('studio 2 ready',((Date.now()-t0)/1000).toFixed(0)+'s',await p.evaluate(()=>{const Y=window.__dyb.DYB;return JSON.stringify({err:Y.err,cars:[...Y.S2.values()].map(S=>({k:S.key,tris:S.tris,draws:S.draws,ms:S.ms,pivot:S.pivot,trans:S.trans,tips:S.tips.length}))});}));
  for(const j of jobs.length?jobs:['start=0']){const i=j.indexOf('='),name=j.slice(0,i),code=j.slice(i+1),t1=Date.now();
    const r=await p.evaluate(async code=>{const G=window.__game,Y=window.__dyb;return await (new Function('G','Y','return (async()=>{'+(code.includes('return')?code:'return '+(code||'0'))+'})()'))(G,Y);},code);
    await p.waitForTimeout(+(process.env.WAIT||2500));await p.screenshot({path:path.join(out,name+'.png'),timeout:600000});
    console.log(name,((Date.now()-t1)/1000).toFixed(0)+'s',JSON.stringify(r));}
  console.log(errs.length?'page errors:\n  '+[...new Set(errs)].slice(0,12).join('\n  '):'no page errors');await b.close();
})();
