/* the drones: the car driven along the road at speed, a picture from each drone; then a spin under Drone orbit, the
   drone's angle round the car against the car's own heading */
const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 const p=await b.newPage({viewport:{width:800,height:450}});const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error')errs.push(m.text().slice(0,300));});
 await p.goto('file://'+require('path').resolve(process.argv[2]||'salt-and-sand.html')+'?quality=mobile');
 await p.waitForFunction(()=>window.__dyb&&document.getElementById('loading').hidden&&window.__dyb.DYB.S2.size>0,null,{timeout:600000,polling:500});
 await p.evaluate(()=>{const Y=window.__dyb;Y.GAME.hold=true;document.getElementById('sasDrive').click();Y.placeCar(0,1.9,0);
   Y.setTestInput({steer:0,thr:1,brk:0,hb:0,nos:false});for(let i=0;i<300;i++){Y.APP.t+=1/60;Y.step(1/60);if(i%30==29)Y.render(1/60);}});
 for(const cam of [4,5,6,7,8]){
  const r=await p.evaluate(async(cam)=>{const Y=window.__dyb;Y.APP.cam=cam;Y.CAM.cut=true;Y.setTestInput({steer:0,thr:.7,brk:0,hb:0,nos:false});
    for(let i=0;i<90;i++){Y.APP.t+=1/60;Y.step(1/60);if(i>=76||i%10==9)Y.render(1/60);if(i%10==9)await new Promise(r=>setTimeout(r,10));}
    const t=Y.GAME.car,c=Y.CAM.last||{};const e=c.eye||[0,0,0];
    return {cam:['','','','','Drone lead','Drone tail','Drone left','Drone right','Drone orbit'][cam],mph:Math.round(t.speed*2.237),heightAboveCar:+(e[1]-t.p[1]).toFixed(1),out:+Math.hypot(e[0]-t.p[0],e[2]-t.p[2]).toFixed(1)};},cam);
  await p.screenshot({path:'drone_'+cam+'.png',timeout:900000});console.log(JSON.stringify(r));}
 /* a handbrake spin on the salt under Drone orbit and Drone tail: how far the car turns, how far the drone moves round it */
 const spin=await p.evaluate(async()=>{const Y=window.__dyb,out={};
   for(const cam of [8,5]){Y.placeCar(300,-120,0);Y.APP.cam=cam;Y.CAM.cut=true;Y.setTestInput({steer:0,thr:1,brk:0,hb:0,nos:false});
     for(let i=0;i<240;i++){Y.APP.t+=1/60;Y.step(1/60);if(i%40==39)Y.render(40/60);}
     const head=()=>{const M=Y.GAME.car.M;return Math.atan2(-M[6],M[0]);},droneA=()=>{const e=Y.CAM.last.eye,t=Y.GAME.car.p;return Math.atan2(-(e[2]-t[2]),e[0]-t[0]);};
     let h0=head(),a0=droneA(),hT=0,aT=0,ph=h0,pa=a0;const wr=a=>{while(a>Math.PI)a-=2*Math.PI;while(a<-Math.PI)a+=2*Math.PI;return a;};
     Y.setTestInput({steer:1,thr:1,brk:0,hb:1,nos:false});
     for(let i=0;i<180;i++){Y.APP.t+=1/60;Y.step(1/60);const h=head();hT+=wr(h-ph);ph=h;if(i%5==4){Y.render(5/60);await new Promise(r=>setTimeout(r,5));const a=droneA();aT+=wr(a-pa);pa=a;}}
     out[cam===8?'orbit':'tail']={carTurnedDeg:Math.round(hT*180/Math.PI),droneMovedRoundDeg:Math.round(aT*180/Math.PI),inSeconds:3};}
   return out;});
 await p.screenshot({path:'drone_spin.png',timeout:900000});console.log('spin',JSON.stringify(spin));
 console.log(errs.slice(0,6).join('\n')||'no errors');await b.close();})();
