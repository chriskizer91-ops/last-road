/* the Cameras drop-down (Settings) and the Drive tab's camera row, on a phone held sideways (915 x 412, touch):
   pictures of both, and a tap or two: a camera switched off leaves the row; a Director time stepped up.
   node tools/camsui.js [salt-and-sand.html]   (pictures camsui_*.png here) */
const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 const c=await b.newContext({viewport:{width:915,height:412},deviceScaleFactor:2,isMobile:true,hasTouch:true});const p=await c.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.goto('file://'+require('path').resolve(process.argv[2]||'salt-and-sand.html'));
 await p.waitForFunction(()=>window.__dyb&&document.getElementById('loading').hidden,null,{timeout:900000,polling:500});
 await p.evaluate(()=>{const Y=window.__dyb;Y.GAME.hold=true;Y.showFull(false);Y.showTab('settings');document.querySelector('#sCams details').open=true;});
 await p.waitForTimeout(400);
 const row=()=>p.evaluate(()=>[...document.querySelectorAll('#mCam > *')].map(e=>e.textContent+(e.getAttribute('aria-pressed')==='true'?'*':'')).join(' | '));
 console.log('Drive row at the start:',await row());
 const sec=await p.$('#sCams');await sec.screenshot({path:'camsui_settings.png'});
 /* switch Far on and Hood off; Chase's Director time two steps longer */
 const tap=async(name,sel)=>{const h=await p.evaluateHandle(([n,s])=>[...document.querySelectorAll('#sCamList .camrow')].find(r=>r.querySelector('.nm').textContent===n).querySelector(s),[name,sel]);await h.asElement().tap();};
 await tap('Far','.sw');await tap('Hood','.sw');await tap('Chase','.upb');await tap('Chase','.upb');
 console.log('after Far on, Hood off, Chase +2:',JSON.stringify(await p.evaluate(()=>{const S=window.__dyb.CAMSET;return {on:S.on.map(i=>window.__dyb.CAMS[i]),chase:S.t[0]};})));
 console.log('Drive row now:',await row());
 console.log('saved:',await p.evaluate(()=>localStorage.getItem('sas:cams')));
 await p.evaluate(()=>{window.__dyb.showTab('drive');});await p.waitForTimeout(300);
 const cam=await p.$('#mCam');await cam.scrollIntoViewIfNeeded();const bb=await cam.boundingBox();
 await p.screenshot({path:'camsui_drive.png',clip:{x:0,y:Math.max(0,bb.y-60),width:915,height:bb.height+100}});
 console.log(errs.slice(0,6).join('\n')||'no errors');await b.close();})();
