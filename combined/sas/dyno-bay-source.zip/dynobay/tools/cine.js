/* the Cinematic camera on the road: the car driven east at speed, a picture every ~2.5 s of game time, with where the camera stands */
const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 const p=await b.newPage({viewport:{width:800,height:450}});const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error')errs.push(m.text().slice(0,300));});
 await p.goto('file:///home/claude/dynobay/salt-and-sand.html?quality=mobile');
 await p.waitForFunction(()=>window.__dyb&&document.getElementById('loading').hidden&&window.__dyb.DYB.S2.size>0,null,{timeout:600000,polling:500});
 await p.evaluate(()=>{const Y=window.__dyb;Y.GAME.hold=true;document.getElementById('sasDrive').click();Y.placeCar(0,1.9,0);
   Y.setTestInput({steer:0,thr:1,brk:0,hb:0,nos:false});for(let i=0;i<360;i++){Y.APP.t+=1/60;Y.step(1/60);if(i%30==29)Y.render(1/60);}
   Y.APP.cam=3;Y.CAM.cut=true;});
 for(let s=0;s<6;s++){
  const r=await p.evaluate(async(s)=>{const Y=window.__dyb;const n=s===0?20:150;for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.step(1/60);if(i>=n-14||i%10==9)Y.render(1/60);if(i%10==9)await new Promise(r=>setTimeout(r,10));}
    const t=Y.GAME.car,C=Y.CINE;return {mph:Math.round(t.speed*2.237),car:[Math.round(t.p[0]),Math.round(t.p[2])],cam:C.p.map(v=>Math.round(v)),dist:Math.round(C.d),lensDeg:+C.fov.toFixed(1)};},s);
  await p.screenshot({path:'/tmp/cine_'+s+'.png',timeout:900000});console.log('shot',s,JSON.stringify(r));}
 console.log(errs.slice(0,6).join('\n')||'no errors');await b.close();})();
