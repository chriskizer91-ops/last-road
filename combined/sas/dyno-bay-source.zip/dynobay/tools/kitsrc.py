"""The Studio kit's source in the viewer's own order (viewer/build.sh): the game's builders, the Studio kit, each car's detail."""
import os,sys
def kit_source(src):
    out=[]
    for sub in ('game','hd'):
        d=os.path.join(src,sub)
        for f in sorted(os.listdir(d)):
            if f.endswith('.js'):out.append(open(os.path.join(d,f),encoding='utf8').read());out.append('\n;\n')
    cd=os.path.join(src,'cars')
    for car in sorted(os.listdir(cd)):
        p=os.path.join(cd,car)
        if not os.path.isdir(p):continue
        for f in sorted(os.listdir(p)):
            if f.endswith('.js'):out.append(open(os.path.join(p,f),encoding='utf8').read());out.append('\n;\n')
    return ''.join(out)
if __name__=='__main__':
    sys.stdout.write(kit_source(sys.argv[1]))
