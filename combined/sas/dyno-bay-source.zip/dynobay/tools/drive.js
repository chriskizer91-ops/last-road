/* Salt & Sand's checks, with pictures: boot (the bay is the menu), Drive out onto the road, the car driven on the
   road, on the dunes and on the salt (speed, gear, the surface under each wheel), from the game's cameras.
   The loop is held and the page stepped here. usage: node tools/drive.js <page.html> <out-dir>   env: W, H, Q, FR */
const {chromium}=require('/opt/npm-tools/node_modules/playwright');const fs=require('fs'),path=require('path');
const page=path.resolve(process.argv[2]),out=process.argv[3]||'/tmp/sas';fs.mkdirSync(out,{recursive:true});
const FR=+(process.env.FR||8),ONLY=(process.env.ONLY||'').split(',').filter(Boolean);
(async()=>{
  const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--autoplay-policy=no-user-gesture-required']});
  const p=await b.newPage({viewport:{width:+(process.env.W||960),height:+(process.env.H||540)},deviceScaleFactor:1});
  const errs=[];p.on('pageerror',e=>errs.push('pageerror: '+e.message));p.on('console',m=>{if(m.type()==='error'||m.type()==='warning')errs.push(m.type()+': '+m.text().slice(0,300));});
  const t0=Date.now(),T=()=>((Date.now()-t0)/1000).toFixed(0)+'s';
  await p.goto('file://'+page+'?quality='+(process.env.Q||'mobile'));
  await p.waitForFunction(()=>window.__dyb&&document.getElementById('loading').hidden&&window.__dyb.DYB.S2.size>0,null,{timeout:600000,polling:500});
  console.log('booted, Studio 2 ready',T());
  await p.evaluate(()=>{const Y=window.__dyb;
    window.TT={
      /* sec seconds of the game, the inputs given; a frame drawn every `every` steps so the world comes in round the car */
      drive(sec,inp,every=12){Y.setTestInput(Object.assign({steer:0,thr:0,brk:0,hb:0,nos:false},inp));const n=Math.round(sec*60);
        TT.air=0;for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.step(1/60);if(Y.GAME.car.wheels.every(w=>!w.contact))TT.air++;if(i%every===every-1)Y.render(1/60);}TT.air=+(TT.air/60).toFixed(2);return TT.info();},
      draw(n){for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.step(1/60);Y.render(1/60);}},
      info(){const t=Y.GAME.car,pt=t.pt;return {mph:+(t.speed*2.237).toFixed(1),gear:pt.gear,rpm:Math.round((pt.we||0)*60/6.2832),x:Math.round(t.p[0]),y:+t.p[1].toFixed(2),z:Math.round(t.p[2]),
        surf:t.wheels.map(w=>w.contact?w.surf:'air').join(','),air:TT.air,tris:Y.APP.tris,draws:Y.GLC.n,chunks:Y.WORLD.chunks.size,state:Y.GAME.state,s2:!!Y.DYB.S2.get(Y.s2Key(t.bi))};},
      place(x,z,yaw){Y.placeCar(x,z,yaw);Y.CAM.cut=true;Y.WORLD.rush=Y.APP.t+4;}};});
  const shot=async(name,code,n=FR)=>{if(ONLY.length&&!ONLY.includes(name))return;const r=await p.evaluate(async([code,n])=>{const Y=window.__dyb;const v=await (new Function('Y','TT','return (async()=>{'+code+'})()'))(Y,TT);TT.draw(n);return v;},[code,n]);
    await p.screenshot({path:path.join(out,name+'.png'),timeout:900000});console.log(name,T(),JSON.stringify(r));};
  await p.evaluate(()=>{window.__dyb.GAME.hold=true;});
  await shot('menu_bay',"return {state:Y.GAME.state,full:Y.SHOW.full};",4);
  /* the bay's Drive button */
  await shot('road_start',"document.getElementById('sasDrive').click();Y.APP.cam=0;Y.CAM.cut=true;const a=TT.drive(2,{thr:0});return a;",10);
  await shot('road_fast',"return TT.drive(7,{thr:1});",8);
  await shot('road_far_cam',"Y.APP.cam=1;Y.CAM.cut=true;return TT.drive(1,{thr:.6});",8);
  await shot('dunes',"Y.APP.cam=1;Y.CAM.cut=true;TT.place(420,170,0);TT.drive(1.5,{thr:0});return TT.drive(5,{thr:.9});",14);
  await shot('dunes_jump',"return TT.drive(4,{thr:1});",10);
  await shot('dunes_hood',"Y.APP.cam=2;Y.CAM.cut=true;return TT.drive(1.5,{thr:.7,steer:.2});",10);
  await shot('salt',"Y.APP.cam=0;Y.CAM.cut=true;TT.place(800,-150,0);TT.drive(1,{thr:0});return TT.drive(8,{thr:1});",10);
  await shot('look_south',"TT.place(1600,-30,-1.5708);Y.APP.cam=1;Y.CAM.cut=true;return TT.drive(2,{thr:0,brk:1});",10);
  await shot('back_to_bay',"Y.openMenu(false);return {state:Y.GAME.state,full:Y.SHOW.full};",6);
  console.log(errs.length?'page errors:\n  '+[...new Set(errs)].slice(0,14).join('\n  '):'no page errors');await b.close();
})();
