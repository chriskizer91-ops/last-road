/* the low drone (50 ft up, a slower Cinematic): the car driven east along the road at speed through a whole shot and
   into the next, a line a second of where the drone is against the car; pictures as the car comes, passes and goes;
   then the same across the dunes, how high it climbs to see over them.
   node tools/lowdrone.js [salt-and-sand.html]   (pictures lowdrone_*.png here) */
const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 const p=await b.newPage({viewport:{width:800,height:450}});const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error')errs.push(m.text().slice(0,300));});
 await p.goto('file://'+require('path').resolve(process.argv[2]||'salt-and-sand.html')+'?quality=mobile');
 await p.waitForFunction(()=>window.__dyb&&document.getElementById('loading').hidden&&window.__dyb.DYB.S2.size>0,null,{timeout:600000,polling:500});
 /* one stretch: n steps of the game, one picture-frame drawn, where everything is */
 const run=(n,inp)=>p.evaluate(async([n,inp])=>{const Y=window.__dyb;Y.setTestInput(inp);
   for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.step(1/60);}Y.render(n/60);await new Promise(r=>setTimeout(r,5));
   const t=Y.GAME.car,L=Y.LOWD,e=Y.CAM.last.eye,d=L.dir,rel=[t.p[0]-e[0],t.p[2]-e[2]];
   return {mph:Math.round(t.speed*2.237),droneMph:Math.round(L.sp*2.237),aboveGround:+(e[1]-Y.RANCH.W.heightAt(e[0],e[2])).toFixed(1),
     aboveCar:+(e[1]-t.p[1]).toFixed(1),dist:Math.round(Math.hypot(t.p[0]-e[0],t.p[1]-e[1],t.p[2]-e[2])),
     droneAhead:Math.round(-(rel[0]*d[0]+rel[1]*d[2])),fov:+L.fov.toFixed(1),o:L.o[0]+','+L.o[2],shotT:+L.shot.toFixed(1)};},[n,inp]);
 const go=async(label,place,inp,secs,pics)=>{
   await p.evaluate(([place])=>{const Y=window.__dyb;Y.GAME.hold=true;if(!Y.GAME.state||Y.GAME.state!=='drive')document.getElementById('sasDrive').click();
     Y.placeCar(...place);Y.APP.cam=0;Y.CAM.cut=true;Y.setTestInput({steer:0,thr:1,brk:0,hb:0,nos:false});
     for(let i=0;i<360;i++){Y.APP.t+=1/60;Y.step(1/60);if(i%60==59)Y.render(1);}
     Y.APP.cam=9;Y.CAM.cut=true;},[place]);
   let shots=0,lastO=null,minD=1e9,took={},t0=0;const rows=[];
   for(let k=0;k<secs*2;k++){const r=await run(30,inp);if(r.o!==lastO){shots++;lastO=r.o;t0=k/2;}
     r.t=k/2;r.shot=shots;rows.push(r);if(k%2==1)console.log(label,JSON.stringify(r));
     if(shots===1){minD=Math.min(minD,r.dist);
       for(const [name,test] of pics)if(!took[name]&&test(r)){took[name]=1;await p.screenshot({path:'lowdrone_'+label+'_'+name+'.png',timeout:900000});}}}
   return rows;};
 const road=await go('road',[0,1.9,0],{steer:0,thr:.62,brk:0,hb:0,nos:false},40,
   [['coming',r=>r.t>=2],['passing',r=>r.droneAhead<4],['going',r=>r.droneAhead<-30]]);
 const s1=road.filter(r=>r.shot===1),end=road.find(r=>r.shot===2);
 console.log('road shot',JSON.stringify({firstShotSeconds:end?end.t:'longer than '+road.length/2,
   startedAheadM:s1[0].droneAhead,closestM:Math.min(...s1.map(r=>r.dist)),carMph:[Math.min(...s1.map(r=>r.mph)),Math.max(...s1.map(r=>r.mph))],
   droneMph:[Math.min(...s1.map(r=>r.droneMph)),Math.max(...s1.map(r=>r.droneMph))],aboveGround:[Math.min(...s1.map(r=>r.aboveGround)),Math.max(...s1.map(r=>r.aboveGround))],
   lens:[Math.min(...s1.map(r=>r.fov)),Math.max(...s1.map(r=>r.fov))]}));
 const dn=await go('dunes',[420,170,0],{steer:0,thr:.8,brk:0,hb:0,nos:false},16,[['over',r=>r.t>=6]]);
 console.log('dunes',JSON.stringify({aboveGround:[Math.min(...dn.map(r=>r.aboveGround)),Math.max(...dn.map(r=>r.aboveGround))],
   aboveCar:[Math.min(...dn.map(r=>r.aboveCar)),Math.max(...dn.map(r=>r.aboveCar))],shots:dn[dn.length-1].shot}));
 console.log(errs.slice(0,6).join('\n')||'no errors');await b.close();})();
