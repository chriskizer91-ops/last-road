const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const shots=JSON.parse(process.argv[2]);
(async()=>{const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 const p=await b.newPage({viewport:{width:800,height:450}});const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error')errs.push(m.text().slice(0,300));});
 await p.goto('file:///home/claude/dynobay/salt-and-sand.html?quality=mobile');
 await p.waitForFunction(()=>window.__dyb&&document.getElementById('loading').hidden&&window.__dyb.DYB.S2.size>0,null,{timeout:600000,polling:500});
 await p.evaluate(()=>{const Y=window.__dyb;Y.GAME.hold=true;document.getElementById('sasDrive').click();});
 for(const [name,code,n] of shots){
  const r=await p.evaluate(async([code,n])=>{const Y=window.__dyb;const v=await (new Function('Y','return (async()=>{'+code+'})()'))(Y);
    Y.setTestInput({steer:0,thr:0,brk:1,hb:1,nos:false});for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.step(1/60);Y.render(1/60);if(i%5==4)await new Promise(r=>setTimeout(r,30));}
    const t=Y.GAME.car;return {v,p:t.p.map(x=>+x.toFixed(1)),tris:Y.APP.tris,draws:Y.GLC.n};},[code,n]);
  await p.screenshot({path:'/tmp/look_'+name+'.png',timeout:900000});console.log(name,JSON.stringify(r));}
 console.log(errs.slice(0,8).join('\n')||'no errors');await b.close();})();
