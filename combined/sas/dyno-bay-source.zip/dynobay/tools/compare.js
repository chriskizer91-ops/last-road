/* The Dyno Bay beside the Studio 2 viewer, at the laptop's screen size: the viewer's Studio 2 car, then the bay as it
   starts (what's on the dyno while Studio 2 is made), then the bay's Studio 2 from the front and in the engine bay,
   with the render size the bay draws at.  usage: node tools/compare.js <dyno-bay.html> <viewer.html> <out-dir> [car] */
const {chromium}=require('/opt/npm-tools/node_modules/playwright');const fs=require('fs'),path=require('path');
const [bay,viewer,out,car='stock']=[path.resolve(process.argv[2]),path.resolve(process.argv[3]),process.argv[4]||'/tmp/cmp',process.argv[5]];fs.mkdirSync(out,{recursive:true});
const W=+(process.env.W||1920),H=+(process.env.H||1080),N=+(process.env.N||16);
(async()=>{
  const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
  const errs=[];
  {const p=await b.newPage({viewport:{width:W,height:H},deviceScaleFactor:1});p.on('pageerror',e=>errs.push('viewer: '+e.message));
    await p.goto('file://'+viewer+'?car='+car+'&v=studio2&view=front34&shots=1');
    await p.waitForFunction(()=>window.VIEWER&&VIEWER.stats()&&document.getElementById('loading').hidden,null,{timeout:600000,polling:500});
    const st=await p.evaluate(()=>{VIEWER.setHood(true);VIEWER.snap();return VIEWER.stats();});await p.waitForTimeout(800);
    await p.screenshot({path:path.join(out,'viewer.png'),timeout:600000});console.log('viewer',JSON.stringify(st));await p.close();}
  const p=await b.newPage({viewport:{width:W,height:H},deviceScaleFactor:1});p.on('pageerror',e=>errs.push('bay: '+e.message));
  p.on('console',m=>{if(m.type()==='error')errs.push('bay: '+m.text().slice(0,300));});
  await p.goto('file://'+bay+(process.env.Q?'?quality='+process.env.Q:''));
  await p.waitForFunction(()=>window.__dyb&&document.getElementById('loading').hidden,null,{timeout:600000,polling:200});
  await p.screenshot({path:path.join(out,'bay_while_building.png'),timeout:600000});
  console.log('while building',await p.evaluate(()=>{const Y=window.__dyb;return JSON.stringify({ready:[...Y.DYB.S2.keys()],building:Y.DYB.busy&&Y.DYB.busy.k,badge:document.getElementById('s2b')&&document.getElementById('s2b').textContent});}));
  await p.waitForFunction(()=>{const Y=window.__dyb;return Y.DYB.S2.size>0||Object.keys(Y.DYB.err).length;},null,{timeout:600000,polling:300});
  for(const [name,view] of [['bay_front34','front34'],['bay_engine','bay']]){
    const r=await p.evaluate(([view,N])=>{const Y=window.__dyb,G=window.__game;Y.GAME.hold=true;Y.showSetView(view);Y.SHOW.cam=null;Y.SHOW.yaw=0;
      for(let i=0;i<N;i++){Y.APP.t+=1/60;Y.drsStep(1/60);Y.render(1/60);}
      const R=G.R,k=Y.s2Key(Y.APP.bi),S=Y.DYB.S2.get(k);
      return {car:k,tris:S&&S.tris,tier:new URLSearchParams(location.search).get('quality')||'(start tier)',canvas:[G.gl.drawingBufferWidth,G.gl.drawingBufferHeight],render:[R.iw,R.ih],scale:R.scale};},[view,N]);
    await p.screenshot({path:path.join(out,name+'.png'),timeout:600000});console.log(name,JSON.stringify(r));}
  console.log(errs.length?'errors:\n  '+errs.slice(0,8).join('\n  '):'no page errors');await b.close();
})();
