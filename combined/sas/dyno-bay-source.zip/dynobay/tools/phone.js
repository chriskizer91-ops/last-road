/* a phone held sideways (412 x 915 CSS pixels turned, touch): boot into the bay, Drive, then the bar's chip back to the bay */
const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 const p=await b.newPage({viewport:{width:915,height:412},hasTouch:true,isMobile:true,deviceScaleFactor:1});const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error')errs.push(m.text().slice(0,300));});
 await p.goto('file:///home/claude/dynobay/salt-and-sand.html');
 await p.waitForFunction(()=>window.__dyb&&document.getElementById('loading').hidden&&window.__dyb.DYB.S2.size>0,null,{timeout:900000,polling:500});
 const st=()=>p.evaluate(()=>{const Y=window.__dyb,c=document.getElementById('menuBtn'),r=c.getBoundingClientRect();return {state:Y.GAME.state,bay:Y.SHOW.full,chip:c.textContent,chipShown:r.width>0&&getComputedStyle(c).display!=='none',tier:new URLSearchParams(location.search).get('quality')||'start tier'};});
 const draw=n=>p.evaluate(async n=>{const Y=window.__dyb;Y.GAME.hold=true;for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.step(1/60);Y.render(1/60);await new Promise(r=>setTimeout(r,10));}},n);
 await draw(4);await p.screenshot({path:'/tmp/phone_1_bay.png',timeout:900000});console.log('1 bay',JSON.stringify(await st()));
 await p.tap('#sasDrive');await new Promise(r=>setTimeout(r,600));await draw(10);await p.screenshot({path:'/tmp/phone_2_drive.png',timeout:900000});console.log('2 drive',JSON.stringify(await st()));
 await p.tap('#menuBtn');await new Promise(r=>setTimeout(r,600));await draw(6);await p.screenshot({path:'/tmp/phone_3_back.png',timeout:900000});console.log('3 tapped Bay',JSON.stringify(await st()));
 console.log(errs.slice(0,6).join('\n')||'no errors');await b.close();})();
