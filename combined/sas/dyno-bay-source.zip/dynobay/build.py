"""Builds dyno-bay.html: Redline County: Wide Open 2: Road Not Found + Traffic cut down to its garage and dyno bay,
with the car on the turntable and the dyno drawn as its Studio 2 (Salt Mini Plus's models).

usage: python3 -I build.py <game.html> <salt-mini-plus models/src> <out.html> [--dunes]

--dunes builds Salt & Sand instead (dunes.py): the same garage and dyno bay as its menu, and the game driven on
half salt flats, half white sand dunes, a road through the middle.

Every change to the game is a replacement of a piece of its text that must be there exactly once (the build
stops if the game has changed under it). The Studio kit goes in as text, for a worker to build the cars from."""
import json,os,re,sys
HERE=os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0,os.path.join(HERE,'tools'))
from kitsrc import kit_source

game,models,out=sys.argv[1],sys.argv[2],sys.argv[3]
DUNES='--dunes' in sys.argv[4:]
G=open(game,encoding='utf8').read()
rd=lambda f:open(os.path.join(HERE,'src',f),encoding='utf8').read()

def rep(old,new,n=1):
    global G
    c=G.count(old)
    if c!=n:raise SystemExit(f'expected {n} of {old[:90]!r}, found {c}')
    G=G.replace(old,new)

# ---- the page: its name, its own saves (never Road Not Found's), what it leaves out ----
NAME,TAG,PFX=('Salt &amp; Sand','Salt &amp; Sand · Studio 2','sas:') if DUNES else ('Dyno Bay','Dyno Bay · Studio 2','dyb:')
rep('<title>Redline County: Wide Open 2: Road Not Found + Traffic</title>',f'<title>Redline County: {NAME} (Studio 2)</title>')
rep('<h1>Redline County <small class="tagw">Wide Open 2 · Road Not Found + Traffic</small></h1>',f'<h1>Redline County <small class="tagw">{TAG}</small></h1>')
rep('localStorage.getItem(k)',f"localStorage.getItem('{PFX}'+k)")
rep('localStorage.setItem(k,String(v))',f"localStorage.setItem('{PFX}'+k,String(v))")
rep('localStorage.removeItem(k)',f"localStorage.removeItem('{PFX}'+k)")
# (the ground's photographs: only the concrete is seen here, in the studio's floor; the police's recorded voices: none)
n0=len(G)
G,k=re.subn(r'(\{id:"(?!concrete")[a-z_0-9]+",t:"[A-Z0-9]+",m:\[[^\]]*\],scale:[0-9.]+,)has:true,src:"data:image/webp;base64,[A-Za-z0-9+/=]*"\}',r'\1has:false,src:""}',G)
if k!=16:raise SystemExit(f'ground photographs: {k}')
G,k=re.subn(r'^const VOICES=\{"police.*\};?$','const VOICES={};',G,flags=re.M)
if k!=1:raise SystemExit('voices')
print(f'left out {(n0-len(G))/1e6:.1f} MB of the open world\'s pictures and voices')

# ---- the start: the bay's graphics on a laptop, the garage tab, the bay on the dyno with the hood up ----
rep("const GFX_START=matchMedia('(pointer: coarse)').matches?'mobile':'low';","const GFX_START=matchMedia('(pointer: coarse)').matches?'mobile':'high';")
rep("const MENU={tab:'drive'};","const MENU={tab:'garage'};")
rep("const SHOW={full:false,stage:'dark',view:'front34',spin:true,hood:false,","const SHOW={full:false,stage:'dark',view:'front34',spin:false,hood:true,")
rep("fanA:0,fanW:0,lift:0,cvtR:0,","fanA:0,fanW:0,lift:1,cvtR:0,")
rep("tab:'look',mode:'free',room:'garage',listen:0,whp:0,peak:{hp:0,rpm:0},starting:false,spinWas:false,","tab:'look',mode:'drive',room:'garage',listen:0,whp:0,peak:{hp:0,rpm:0},starting:false,spinWas:true,")
rep("['low','Low',-24,1.5,6.6,.62],","['low','Low',-24,1.5,6.6,.62],['under','Under',-32,-36,5.2,.3],")
# (the views a little closer in than the game's, so the car fills more of the picture, as in the Studio 2 viewer)
rep("const SHOW_VIEWS=[['front34','Front ¾',-38,8,8.6,.86],['side','Side',90,2.5,8.4,.82],['rear34','Rear ¾',142,9,8.6,.86],['front','Front',0,4,7.4,.86],",
    "const SHOW_VIEWS=[['front34','Front ¾',-38,8,6.7,.86],['side','Side',90,2.5,6.6,.82],['rear34','Rear ¾',142,9,6.7,.86],['front','Front',0,4,5.8,.86],")
rep("['rear','Rear',180,5,7.4,.86],['top','Top',-35,58,9.6,.55],['low','Low',-24,1.5,6.6,.62],","['rear','Rear',180,5,5.8,.86],['top','Top',-35,58,7.6,.55],['low','Low',-24,1.5,5.2,.62],")

# ---- the bay's camera: all the way round, underneath, close in, the centre slid along the car ----
i0=G.index('/* drag to turn round the car, pinch or scroll to come closer');i1=G.index('/* a button you hold')
if G.count('function showPointer(){')!=1:raise SystemExit('showPointer')
G=G[:i0]+rd('s2cam.js')+G[i1:]
rep("c.d+=(tgt.d-c.d)*k;c.ty+=(tgt.ty-c.ty)*k;","c.d+=(tgt.d-c.d)*k;c.ty+=(tgt.ty-c.ty)*k;for(const q of ['ox','oy','oz'])c[q]=(c[q]||0)+((tgt[q]||0)-(c[q]||0))*k;")
rep("e=[dd*Math.cos(ph)*Math.cos(th),ty+dd*Math.sin(ph),-dd*Math.cos(ph)*Math.sin(th)];let t=[0,ty,0];",
    "e=[(c.ox||0)+dd*Math.cos(ph)*Math.cos(th),ty+(c.oy||0)+dd*Math.sin(ph),(c.oz||0)-dd*Math.cos(ph)*Math.sin(th)];let t=[c.ox||0,ty+(c.oy||0),c.oz||0];")
# (under the floor: the floor, the turntable and the dyno's deck out of the way, a light from below, as on a lift)
rep("const cam=showCam(PIC.w/PIC.h,dt),Mc=M4RY(SHOW.yaw),dh=dynoH(),Mcar=dh>.001?M4.mul(Mc,M4T(0,dh,0)):Mc;",
    "const cam=showCam(PIC.w/PIC.h,dt),Mc=M4RY(SHOW.yaw),dh=dynoH(),Mcar=dh>.001?M4.mul(Mc,M4T(0,dh,0)):Mc;DYB.under=!shed&&cam.eye[1]<-.02;")
rep("probePos:[0,1.1+dh,0],dyn,headlights:null,occ:LOOK.occ?occ:[]","probePos:[0,1.1+dh,0],dyn,headlights:null,occ:LOOK.occ&&!(DYB.under&&DYB.noOcc)?occ:[]")
rep("gl.uniformMatrix4fv(u.uM,false,M4_ID);drawMesh(st.stage);gl.uniformMatrix4fv(u.uM,false,this.Mc);drawMesh(st.table);tris+=st.tris;}",
    "if(!DYB.under){gl.uniformMatrix4fv(u.uM,false,M4_ID);drawMesh(st.stage);gl.uniformMatrix4fv(u.uM,false,this.Mc);drawMesh(st.table);tris+=st.tris;}}")
rep("gl.uniformMatrix4fv(u.uM,false,M4.mul(Mt,M4S(1,k,1)));drawMesh(Y.deck);","if(!DYB.under){gl.uniformMatrix4fv(u.uM,false,M4.mul(Mt,M4S(1,k,1)));drawMesh(Y.deck);}")
rep("let LS=stageLights(S,shed).slice(0,14);",
    "let LS=stageLights(S,shed).slice(0,14);if(DYB.under){E.key*=DYB.uk;LS=LS.slice(0,12).concat([[1.3,-1.05,0,6.5,[1,.97,.92],DYB.ul],[-1.3,-1.05,0,6.5,[1,.97,.92],DYB.ul]]);}")

# ---- the car: Studio 2 on the turntable and the dyno ----
rep("function drawShowCar(i,Mc,hoodA,live,far,dirt,du){","function drawShowCar(i,Mc,hoodA,live,far,dirt,du){\n  /* (Dyno Bay: the car is only ever its Studio 2; while it's made the dyno stands empty. The game's own car only if\n     Studio 2 could not be built at all) */\n  if(live&&!far){const S2=s2For(i),k=s2Key(i);if(S2)return drawS2Car(i,Mc,hoodA,dirt,du,S2);if(k&&!DYB.err[k])return 0;}")
# (no shed of parked cars, which are the game's own: the views, the opening screen and Settings all show the turntable)
rep(",['shed','The shed',-24,14,19.5,1.1]]","]")
rep("const showShed=()=>APP.title&&MENU.tab!=='garage'&&!SHOW.full||SHOW.view==='shed';","const showShed=()=>false;")
rep("function showParked(){const sel=APP.car,out=[];let fresh=false;","function showParked(){return [];const sel=APP.car,out=[];let fresh=false;")
rep("let warm=false,built=0;const park=CARS.map(([c])=>c).filter(c=>c!==APP.car);","let warm=false,built=0;const park=[];")
# (the bay drawn at the tier's full size, every frame: the render size never drops to keep the frame rate up)
rep("function drsStep(dt){if(!RESO||!R||GAME.state!=='drive'&&!showActive()||DEVW.gpuT==='hold')return;",
    "function drsStep(dt){if(RESO&&R&&showActive()){const mx=RESO.max;RESO.scale=mx;if(Math.abs(mx-R.scale)>.001)R.resize(PIC.w,PIC.h,mx);return;}\n  if(!RESO||!R||GAME.state!=='drive'&&!showActive()||DEVW.gpuT==='hold')return;")
rep("  else if(m>=40){\n    vec2 wp=Pw.xz;ground=true;",rd('s2shader.glsl')+"  else if(m>=40){\n    vec2 wp=Pw.xz;ground=true;")

# ---- the garage: the four cars, the slots Studio 2 can show, no driving off ----
rep("for(const [s,sg,sname] of SLOTS){if(sg!==g)continue;","for(const [s,sg,sname] of SLOTS){if(sg!==g||DYB.hide.includes(s))continue;")
rep("const slots=SLOTS.map(s=>s[0]).filter(s=>s!=='paint'&&s!=='wheels')","const slots=SLOTS.map(s=>s[0]).filter(s=>s!=='paint'&&s!=='wheels'&&!DYB.hide.includes(s))")
if not DUNES:rep("function closeMenu(){\n  showLeave();","function closeMenu(){\n  /* (Dyno Bay: no driving off; the menu's way out is the bay) */\n  showFull(true);return;\n  showLeave();")
rep("Your car on the turntable, the whole screen: the views, the hood up on the engine, and the engine on the lab's own sim. Drag to turn round it, pinch or scroll to come closer.",
    "Your car on the dyno as its Studio 2, the whole screen: the views, the hood up on the engine, and the engine on the lab's own sim. Drag to turn round it, over it and underneath; pinch or scroll to come closer; right-drag to slide along it.")
rep('<div class="slots" id="gSlots"></div>','<div class="slots" id="gSlots"></div>\n      <p class="hint" id="gS2">Studio 2 is each build as it\'s modelled, so its body, tyres, wheels and ride height are its own: pick the build under Start from. The paint and everything under the skin are yours to change.</p>')
rep("#bay{position:fixed;inset:0;z-index:7;pointer-events:none}","""#bay{position:fixed;inset:0;z-index:7;pointer-events:none}
/* Dyno Bay: only the garage and the settings; no driving off */
"""+("#mTabs [data-t=chals],#mTabs [data-t=races],#mTabs [data-t=cool],#mTabs [data-t=runs],#tabDev,#mLeave,#menuBtn,.tab[data-tab=drive] section:has(#mModes),.tab[data-tab=drive] section:has(#mTraffic),.tab[data-tab=drive] section:has(#mPlaces){display:none!important}" if DUNES else "#mTabs [data-t=drive],#mTabs [data-t=chals],#mTabs [data-t=races],#mTabs [data-t=cool],#mTabs [data-t=runs],#tabDev,#mGo,#mLeave,#menuBtn{display:none!important}")+"""
#s2b{position:fixed;left:50%;transform:translateX(-50%);top:calc(env(safe-area-inset-top,0px) + 54px);z-index:9;pointer-events:none;padding:7px 14px;border-radius:999px;
  border:1px solid rgba(255,180,60,.45);background:rgba(17,17,25,.86);color:var(--amber);font:600 10.5px/1 var(--f);letter-spacing:.1em;text-transform:uppercase;white-space:nowrap}""")

# ---- the code: the kit as text (for the worker), the Studio 2 pieces, the page's start ----
kit=kit_source(models)
# (the seats noted as the kit makes them, for the Cockpit camera's eye: s2make)
for a_,b_,n_ in [('const seat=(c,w,recl,head=1,bolst=1)=>{','self.KIT_SEATS&&KIT_SEATS.push([c[0],c[1],c[2],w,recl]);',3),(',bucket=(c,s)=>{','self.KIT_SEATS&&KIT_SEATS.push([c[0],c[1],c[2],.5,recl]);',1)]:
    assert kit.count(a_)==n_,(a_,kit.count(a_));kit=kit.replace(a_,a_+b_)
js=lambda s:json.dumps(s).replace('<','\\u003c')
mod=('/* (Dyno Bay) the Studio kit\'s source and the builder of the pieces, for the worker */\nconst S2KIT_SRC='+js(kit)+';\nconst S2MAKE_SRC='+js(rd('s2make.js'))+';\n'
     +rd('s2.js')+'\n')
rep("/* =====================================================================================\n   THE BOOT: the dots",mod+"/* =====================================================================================\n   THE BOOT: the dots")
rep("await paint('Building your car');","await paint('Building your car');dybCars();")
rep("buildMenu();buildDevWorld();mark('car');","buildMenu();buildDevWorld();mark('car');s2For(APP.bi);")
rep("L.hidden=true;openMenu(true);requestAnimationFrame(frame);mark('menu');","L.hidden=true;openMenu(true);dybStart();requestAnimationFrame(frame);mark('menu');")
rep("window.__game={showClutchCap,","window.__dyb={DYB,s2For,s2Key,drawS2Car,drsStep,showSound,render,showBody,showEngine,showMode,showSetView,showFull,showAct,showPullStart,spawnRig,presetRig,pickCar,rigOf,syncGarage,showTab,RIGS,BUILDS,get SHOW(){return SHOW;},get GAME(){return GAME;},get APP(){return APP;},get PULL(){return PULL;},get ENG(){return ENG;}};window.__game={showClutchCap,")

if DUNES:exec(open(os.path.join(HERE,'dunes.py'),encoding='utf8').read())
open(out,'w',encoding='utf8').write(G)
print(f'{out}: {len(G.encode())/1e6:.2f} MB, the kit {len(kit)/1e6:.2f} MB')
